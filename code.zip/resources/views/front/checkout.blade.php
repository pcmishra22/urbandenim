@extends('layouts.eshopper')

@section('title', 'Checkout - EShopper')

@section('content')

    <!-- Page Header -->
    <div class="container-fluid bg-secondary mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px">
            <h1 class="font-weight-semi-bold text-uppercase mb-3">Checkout</h1>
            <div class="d-inline-flex">
                <p class="m-0"><a href="{{ url('/') }}">Home</a></p>
                <p class="m-0 px-2">-</p>
                <p class="m-0">Checkout</p>
            </div>
        </div>
    </div>

    <div class="container-fluid pt-5">
        <div class="row px-xl-5">

            <!-- Left: Address + Coupon form -->
            <div class="col-lg-8">

                @if($errors->any())
                <div class="alert alert-danger alert-dismissible fade show">
                    <ul class="mb-0">@foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul>
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
                @endif

                @if(session('error'))
                <div class="alert alert-danger alert-dismissible fade show">
                    {{ session('error') }}
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
                @endif

                <form method="POST" action="{{ route('checkout.store') }}" id="checkout-form">
                @csrf

                <div class="mb-4">
                    <h4 class="font-weight-semi-bold mb-4">Billing / Shipping Address</h4>

                    @if($addresses->isNotEmpty())
                    <div class="mb-4">
                        <label class="font-weight-medium mb-2">Use a saved address:</label>
                        <div class="row">
                            @foreach($addresses as $address)
                            <div class="col-md-6 mb-2">
                                <div class="border p-3 saved-addr" style="cursor:pointer;border-radius:4px;"
                                     data-full_name="{{ $address->full_name }}"
                                     data-phone="{{ $address->phone }}"
                                     data-street="{{ $address->street }}"
                                     data-city="{{ $address->city }}"
                                     data-state="{{ $address->state }}"
                                     data-postal="{{ $address->postal_code }}"
                                     data-country="{{ $address->country }}">
                                    <strong>{{ $address->full_name }}</strong>
                                    <p class="mb-0 small text-muted">{{ $address->street }}, {{ $address->city }}</p>
                                    <p class="mb-0 small text-muted">{{ $address->state }} {{ $address->postal_code }}</p>
                                    <small class="text-primary">Click to use</small>
                                </div>
                            </div>
                            @endforeach
                        </div>
                        <hr>
                    </div>
                    @endif

                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label>Full Name <span class="text-danger">*</span></label>
                            <input class="form-control @error('shipping_full_name') is-invalid @enderror"
                                   type="text" name="shipping_full_name"
                                   value="{{ old('shipping_full_name', auth()->user()->name ?? '') }}"
                                   placeholder="Full Name">
                            @error('shipping_full_name')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Mobile No <span class="text-danger">*</span></label>
                            <input class="form-control @error('shipping_phone') is-invalid @enderror"
                                   type="text" name="shipping_phone"
                                   value="{{ old('shipping_phone') }}"
                                   placeholder="+91 99999 99999">
                            @error('shipping_phone')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-12 form-group">
                            <label>Street Address <span class="text-danger">*</span></label>
                            <input class="form-control @error('shipping_street') is-invalid @enderror"
                                   type="text" name="shipping_street"
                                   value="{{ old('shipping_street') }}"
                                   placeholder="House no. and Street name">
                            @error('shipping_street')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6 form-group">
                            <label>City <span class="text-danger">*</span></label>
                            <input class="form-control @error('shipping_city') is-invalid @enderror"
                                   type="text" name="shipping_city"
                                   value="{{ old('shipping_city') }}" placeholder="City">
                            @error('shipping_city')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6 form-group">
                            <label>State <span class="text-danger">*</span></label>
                            <input class="form-control @error('shipping_state') is-invalid @enderror"
                                   type="text" name="shipping_state"
                                   value="{{ old('shipping_state') }}" placeholder="State">
                            @error('shipping_state')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6 form-group">
                            <label>ZIP / PIN Code <span class="text-danger">*</span></label>
                            <input class="form-control @error('shipping_postal_code') is-invalid @enderror"
                                   type="text" name="shipping_postal_code"
                                   value="{{ old('shipping_postal_code') }}" placeholder="PIN Code">
                            @error('shipping_postal_code')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Country <span class="text-danger">*</span></label>
                            <input class="form-control @error('shipping_country') is-invalid @enderror"
                                   type="text" name="shipping_country"
                                   value="{{ old('shipping_country', 'India') }}" placeholder="Country">
                            @error('shipping_country')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-12 form-group">
                            <label>Order Notes <small class="text-muted">(optional)</small></label>
                            <textarea class="form-control" name="notes" rows="3"
                                      placeholder="Special delivery instructions">{{ old('notes') }}</textarea>
                        </div>
                    </div>
                </div>

                {{-- Coupon --}}
                <div class="mb-4">
                    <h4 class="font-weight-semi-bold mb-3">Coupon Code <small class="text-muted font-weight-normal">(optional)</small></h4>
                    <div class="input-group" style="max-width:400px;">
                        <input class="form-control" type="text" id="coupon_input" name="coupon_code"
                               value="{{ old('coupon_code', session('coupon_code')) }}" placeholder="Enter coupon code">
                        <div class="input-group-append">
                            <button type="button" class="btn btn-outline-primary" id="apply-coupon-btn">Apply</button>
                        </div>
                    </div>
                    <div id="coupon-msg" class="mt-2 small"></div>
                </div>

                </form>
            </div>

            <!-- Right: Order Summary + Payment -->
            <div class="col-lg-4">

                <!-- Order Total -->
                <div class="card border-secondary mb-4">
                    <div class="card-header bg-secondary border-0">
                        <h4 class="font-weight-semi-bold m-0">Order Total</h4>
                    </div>
                    <div class="card-body">
                        <h5 class="font-weight-medium mb-3">Products</h5>
                        @foreach($cartItems as $item)
                        <div class="d-flex justify-content-between mb-2">
                            <p class="mb-0 text-truncate" style="max-width:200px;">
                                {{ $item['product']->name }}
                                <small class="text-muted">×{{ $item['quantity'] }}</small>
                            </p>
                            <p class="mb-0">₹{{ number_format($item['subtotal'], 2) }}</p>
                        </div>
                        @endforeach
                        <hr class="mt-0">
                        <div class="d-flex justify-content-between mb-3 pt-1">
                            <h6 class="font-weight-medium">Subtotal</h6>
                            <h6 class="font-weight-medium">₹{{ number_format($subtotal, 2) }}</h6>
                        </div>
                        <div class="d-flex justify-content-between">
                            <h6 class="font-weight-medium">Shipping</h6>
                            <h6 class="font-weight-medium">
                                @if($shipping == 0)<span class="text-success">Free</span>
                                @else ₹{{ number_format($shipping, 2) }}
                                @endif
                            </h6>
                        </div>
                        @if($discount > 0)
                        <div class="d-flex justify-content-between mt-2">
                            <h6 class="font-weight-medium text-success">
                                Discount @if($couponCode)<small>({{ $couponCode }})</small>@endif
                            </h6>
                            <h6 class="font-weight-medium text-success">- ₹{{ number_format($discount, 2) }}</h6>
                        </div>
                        @endif
                    </div>
                    <div class="card-footer border-secondary bg-transparent">
                        <div class="d-flex justify-content-between mt-2">
                            <h5 class="font-weight-bold">Grand Total</h5>
                            <h5 class="font-weight-bold">₹{{ number_format($grandTotal, 2) }}</h5>
                        </div>
                    </div>
                </div>

                <!-- Payment Method -->
                <div class="card border-secondary mb-4">
                    <div class="card-header bg-secondary border-0">
                        <h4 class="font-weight-semi-bold m-0">Payment Method</h4>
                    </div>
                    <div class="card-body">

                        {{-- COD --}}
                        <div class="form-group mb-3">
                            <div class="custom-control custom-radio">
                                <input type="radio" class="custom-control-input" name="payment_method"
                                       id="pay_cod" value="cod" form="checkout-form"
                                       {{ old('payment_method','cod') === 'cod' ? 'checked' : '' }}>
                                <label class="custom-control-label" for="pay_cod">
                                    <i class="fa fa-money-bill-wave text-success mr-2"></i>
                                    <strong>Cash on Delivery</strong>
                                    <small class="d-block text-muted">Pay when your order arrives</small>
                                </label>
                            </div>
                        </div>

                        {{-- UPI --}}
                        <div class="form-group mb-3">
                            <div class="custom-control custom-radio">
                                <input type="radio" class="custom-control-input" name="payment_method"
                                       id="pay_upi" value="upi" form="checkout-form"
                                       {{ old('payment_method') === 'upi' ? 'checked' : '' }}>
                                <label class="custom-control-label" for="pay_upi">
                                    <i class="fa fa-mobile-alt text-primary mr-2"></i>
                                    <strong>UPI / Net Banking</strong>
                                    <small class="d-block text-muted">Pay via Google Pay, PhonePe, BHIM, IMPS, Net Banking</small>
                                </label>
                            </div>
                        </div>

                        {{-- Card --}}
                        <div class="form-group mb-2">
                            <div class="custom-control custom-radio">
                                <input type="radio" class="custom-control-input" name="payment_method"
                                       id="pay_card" value="card" form="checkout-form"
                                       {{ old('payment_method') === 'card' ? 'checked' : '' }}>
                                <label class="custom-control-label" for="pay_card">
                                    <i class="fa fa-credit-card text-info mr-2"></i>
                                    <strong>Credit / Debit Card</strong>
                                    <small class="d-block text-muted">Visa, Mastercard, Rupay — secured by Razorpay</small>
                                </label>
                            </div>
                        </div>

                        @error('payment_method')
                        <small class="text-danger d-block mt-2">{{ $message }}</small>
                        @enderror

                        {{-- Razorpay available badge --}}
                        @if(config('services.razorpay.key'))
                        <div class="mt-3 pt-2 border-top d-flex align-items-center">
                            <i class="fa fa-shield-alt text-success mr-2"></i>
                            <small class="text-muted">Online payments secured by <strong>Razorpay</strong></small>
                        </div>
                        @endif
                    </div>
                    <div class="card-footer border-secondary bg-transparent">
                        {{-- Spinner shown while processing --}}
                        <div id="payment-spinner" class="text-center py-2" style="display:none!important;">
                            <div class="spinner-border text-primary" role="status"></div>
                            <p class="small text-muted mt-2 mb-0" id="spinner-msg">Processing…</p>
                        </div>
                        <button type="submit" form="checkout-form" id="place-order-btn"
                                class="btn btn-lg btn-block btn-primary font-weight-bold my-3 py-3">
                            <i class="fa fa-lock mr-2"></i><span id="btn-label">Place Order</span>
                        </button>
                    </div>
                </div>

                <!-- Trust badges -->
                <div class="border p-4">
                    <div class="d-flex align-items-center mb-3">
                        <i class="fa fa-shield-alt text-primary mr-3 fa-lg"></i>
                        <div><h6 class="mb-0">Secure Checkout</h6><small class="text-muted">Your data is protected</small></div>
                    </div>
                    <div class="d-flex align-items-center mb-3">
                        <i class="fa fa-undo text-primary mr-3 fa-lg"></i>
                        <div><h6 class="mb-0">Easy Returns</h6><small class="text-muted">14-day return policy</small></div>
                    </div>
                    <div class="d-flex align-items-center">
                        <i class="fa fa-headset text-primary mr-3 fa-lg"></i>
                        <div><h6 class="mb-0">24/7 Support</h6><small class="text-muted">We're here to help</small></div>
                    </div>
                </div>

            </div>
        </div>
    </div>

@endsection

@push('scripts')

{{-- Saved address autofill --}}
<script>
$('.saved-addr').on('click', function() {
    $('.saved-addr').removeClass('border-primary');
    $(this).addClass('border-primary');
    var d = $(this).data();
    $('[name=shipping_full_name]').val(d.full_name || '');
    $('[name=shipping_phone]').val(d.phone || '');
    $('[name=shipping_street]').val(d.street || '');
    $('[name=shipping_city]').val(d.city || '');
    $('[name=shipping_state]').val(d.state || '');
    $('[name=shipping_postal_code]').val(d.postal || '');
    $('[name=shipping_country]').val(d.country || '');
});

// Update button label when payment method changes
$('input[name=payment_method]').on('change', function() {
    var v = this.value;
    if (v === 'cod') {
        $('#btn-label').text('Place Order');
    } else {
        $('#btn-label').text('Proceed to Pay ₹{{ number_format($grandTotal, 2) }}');
    }
});
</script>

{{-- Razorpay two-step payment flow --}}
@if(config('services.razorpay.key'))
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
(function() {
    var CSRF   = '{{ csrf_token() }}';
    var STORE_PENDING_URL  = '{{ route("checkout.store-pending") }}';
    var CREATE_ORDER_URL   = '{{ route("payment.create-order") }}';
    var VERIFY_URL         = '{{ route("payment.verify") }}';

    function showSpinner(msg) {
        $('#payment-spinner').show();
        $('#spinner-msg').text(msg || 'Processing…');
        $('#place-order-btn').prop('disabled', true);
    }
    function hideSpinner() {
        $('#payment-spinner').hide();
        $('#place-order-btn').prop('disabled', false);
    }

    function getFormData() {
        return {
            _token:                CSRF,
            shipping_full_name:   $('[name=shipping_full_name]').val(),
            shipping_phone:       $('[name=shipping_phone]').val(),
            shipping_street:      $('[name=shipping_street]').val(),
            shipping_city:        $('[name=shipping_city]').val(),
            shipping_state:       $('[name=shipping_state]').val(),
            shipping_postal_code: $('[name=shipping_postal_code]').val(),
            shipping_country:     $('[name=shipping_country]').val(),
            notes:                $('[name=notes]').val(),
            coupon_code:          $('[name=coupon_code]').val(),
            payment_method:       $('input[name=payment_method]:checked').val(),
        };
    }

    function postJson(url, data) {
        return fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': CSRF,
                'Accept': 'application/json',
            },
            body: JSON.stringify(data),
        }).then(function(r) {
            return r.text().then(function(text) {
                var json = null;
                try { json = text ? JSON.parse(text) : null; } catch (e) {}

                if (!r.ok) {
                    var msg = (json && (json.error || json.message))
                        ? (json.error || json.message)
                        : (text || ('Server error (' + r.status + ')'));
                    throw new Error(msg);
                }

                return json || {};
            });
        });
    }


    function validateForm() {
        var required = ['shipping_full_name','shipping_phone','shipping_street','shipping_city','shipping_state','shipping_postal_code','shipping_country'];
        for (var i = 0; i < required.length; i++) {
            if (!$('[name=' + required[i] + ']').val().trim()) {
                var label = $('[name=' + required[i] + ']').prev('label').text().replace('*','').trim();
                alert((label || required[i]) + ' is required.');
                $('[name=' + required[i] + ']').focus();
                return false;
            }
        }
        return true;
    }

    $('#checkout-form').on('submit', function(e) {
        var method = $('input[name=payment_method]:checked').val();

        // COD: normal form submit, no interception needed
        if (method === 'cod') return true;

        // Online payment: intercept
        e.preventDefault();

        if (!validateForm()) return;

        showSpinner('Creating your order…');

        // Step 1: Create order in DB (pending payment)
        postJson(STORE_PENDING_URL, getFormData())
        .then(function(orderData) {
            if (!orderData.order_id) throw new Error('Order creation failed. No order ID returned.');

            showSpinner('Connecting to payment gateway…');

            // Step 2: Create Razorpay order
            return postJson(CREATE_ORDER_URL, { order_id: orderData.order_id, _token: CSRF })
            .then(function(rzpData) {
                return { orderData: orderData, rzpData: rzpData };
            });
        })
        .then(function(result) {
            hideSpinner();
            var orderData = result.orderData;
            var rzpData   = result.rzpData;

            // Step 3: Open Razorpay modal
            var rzpMethod = ($('input[name=payment_method]:checked').val() === 'card') ? 'card' : 'upi';

            var options = {
                key:         rzpData.key,
                amount:      rzpData.amount,
                currency:    rzpData.currency,
                name:        rzpData.name,
                description: rzpData.description,
                order_id:    rzpData.razorpay_order_id,
                prefill:     rzpData.prefill,
                theme:       { color: '#2c3e50' },

                handler: function(response) {
                    // Step 4: Verify payment on our server
                    showSpinner('Verifying payment…');
                    var form = document.createElement('form');
                    form.method = 'POST';
                    form.action = VERIFY_URL;
                    var fields = {
                        '_token':               CSRF,
                        'razorpay_order_id':    response.razorpay_order_id,
                        'razorpay_payment_id':  response.razorpay_payment_id,
                        'razorpay_signature':   response.razorpay_signature,
                        'order_id':             orderData.order_id,
                    };
                    Object.keys(fields).forEach(function(k) {
                        var input = document.createElement('input');
                        input.type  = 'hidden';
                        input.name  = k;
                        input.value = fields[k];
                        form.appendChild(input);
                    });
                    document.body.appendChild(form);
                    form.submit();
                },
                modal: {
                    ondismiss: function() {
                        hideSpinner();
                        // Order exists in DB as 'awaiting_payment' — user can retry
                        alert('Payment cancelled. Your order has been saved. You can complete payment from My Orders.');
                    }
                }
            };

            var rzp = new Razorpay(options);
            rzp.on('payment.failed', function(response) {
                hideSpinner();
                alert('Payment failed: ' + (response.error.description || 'Unknown error') + '. Please try again.');
            });
            rzp.open();
        })
        .catch(function(err) {
            hideSpinner();
            console.error('Payment error:', err);
            alert('Error: ' + (err.message || 'Something went wrong. Please try again or use Cash on Delivery.'));
        });
    });

    // Coupon AJAX
    $('#apply-coupon-btn').on('click', function() {
        var code = $('#coupon_input').val().trim();
        if (!code) { $('#coupon-msg').html('<span class="text-danger">Please enter a coupon code.</span>'); return; }
        $.post('{{ route("coupon.apply") }}', {
            _token: CSRF,
            coupon_code: code,
            subtotal: {{ $subtotal }}
        }, function(res) {
            if (res.success) {
                $('#coupon-msg').html('<span class="text-success"><i class="fa fa-check mr-1"></i>' + res.message + '</span>');
                setTimeout(function() { location.reload(); }, 800);
            } else {
                $('#coupon-msg').html('<span class="text-danger"><i class="fa fa-times mr-1"></i>' + res.message + '</span>');
            }
        }).fail(function() {
            $('#coupon-msg').html('<span class="text-danger">Error applying coupon.</span>');
        });
    });

})();
</script>
@else
{{-- Razorpay not configured: disable online payment options --}}
<script>
$('#pay_upi, #pay_card').prop('disabled', true);
$('#pay_upi').closest('.custom-radio').append('<small class="text-danger d-block mt-1">Razorpay not configured. Please use COD.</small>');
$('#pay_card').closest('.custom-radio').append('<small class="text-danger d-block mt-1">Razorpay not configured. Please use COD.</small>');
</script>
@endif

@endpush
