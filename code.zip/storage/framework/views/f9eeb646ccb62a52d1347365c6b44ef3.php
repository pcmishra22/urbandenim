<?php $__env->startSection('title', 'Admin Dashboard'); ?>



<?php $__env->startSection('content'); ?>
<h1 class="page-title"><i class="fas fa-chart-line"></i> Admin Dashboard</h1>

<div class="row mb-4">
    <div class="col-md-3">
        <div class="stat-card">
            <h6>Total Users</h6>
            <div class="value"><?php echo e($stats['total_users']); ?></div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card">
            <h6>Total Products</h6>
            <div class="value"><?php echo e($stats['total_products']); ?></div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card">
            <h6>Total Orders</h6>
            <div class="value"><?php echo e($stats['total_orders']); ?></div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card">
            <h6>Total Revenue</h6>
            <div class="value">$<?php echo e(number_format($stats['total_revenue'], 0)); ?></div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-3">
        <div class="stat-card">
            <h6>Pending Orders</h6>
            <div class="value" style="color: #f39c12;"><?php echo e($stats['pending_orders']); ?></div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card">
            <h6>Shipped Orders</h6>
            <div class="value" style="color: #3498db;"><?php echo e($stats['shipped_orders']); ?></div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="stat-card">
            <h6>Delivered Orders</h6>
            <div class="value" style="color: #27ae60;"><?php echo e($stats['delivered_orders']); ?></div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <i class="fas fa-receipt"></i> Recent Orders
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Total</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recent_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>#<?php echo e($order->id); ?></td>
                                <td><?php echo e($order->user->name); ?></td>
                                <td>$<?php echo e(number_format($order->total_price, 2)); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo e(strtolower($order->status)); ?>">
                                        <?php echo e(ucfirst($order->status)); ?>

                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center">No orders</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <i class="fas fa-users"></i> Recent Users
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Joined</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recent_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                    <span class="role-badge badge-<?php echo e(strtolower($user->role)); ?>">
                                        <?php echo e(ucfirst($user->role)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($user->created_at->format('M d, Y')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center">No users</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <i class="fas fa-chart-bar"></i> Orders by Status
    </div>
    <div style="padding: 20px;">
        <div class="row">
            <?php $__currentLoopData = $stats['orders_by_status']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div style="background-color: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; margin-bottom: 10px;">
                        <h5 style="color: var(--primary-color); margin-bottom: 10px;"><?php echo e(ucfirst($item->status)); ?></h5>
                        <div style="font-size: 1.5rem; font-weight: bold; color: var(--secondary-color);"><?php echo e($item->count); ?></div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/prakash/urbandenim/resources/views/dashboard/admin.blade.php ENDPATH**/ ?>