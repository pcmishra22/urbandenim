<?php
    use App\Models\SiteSetting;
    $s = SiteSetting::all_settings();
?>

    <!-- Footer Start -->
    <div class="container-fluid bg-secondary text-dark mt-5 pt-5">
        <div class="row px-xl-5 pt-5">
            <div class="col-lg-4 col-md-12 mb-5 pr-3 pr-xl-5">
                <a href="<?php echo e(url('/')); ?>" class="text-decoration-none">
                    <h1 class="mb-4 display-5 font-weight-semi-bold"><span class="text-primary font-weight-bold border border-white px-3 mr-1">E</span>Shopper</h1>
                </a>
                <p>Quality fashion at your fingertips. Shop the latest trends with fast delivery and easy returns.</p>
                <p class="mb-2"><i class="fa fa-map-marker-alt text-primary mr-3"></i><?php echo e($s['store_address'] ?? '123 Street, New York, USA'); ?></p>
                <p class="mb-2"><i class="fa fa-envelope text-primary mr-3"></i><?php echo e($s['store_email'] ?? 'info@eshopper.com'); ?></p>
                <p class="mb-2"><i class="fa fa-phone-alt text-primary mr-3"></i><?php echo e($s['store_phone'] ?? '+012 345 67890'); ?></p>
                
                <div class="d-flex mt-3">
                    <?php if(!empty($s['twitter_url'])): ?>
                    <a class="btn btn-primary btn-square mr-2" href="<?php echo e($s['twitter_url']); ?>" target="_blank" rel="noopener"><i class="fab fa-twitter"></i></a>
                    <?php endif; ?>
                    <?php if(!empty($s['facebook_url'])): ?>
                    <a class="btn btn-primary btn-square mr-2" href="<?php echo e($s['facebook_url']); ?>" target="_blank" rel="noopener"><i class="fab fa-facebook-f"></i></a>
                    <?php endif; ?>
                    <?php if(!empty($s['linkedin_url'])): ?>
                    <a class="btn btn-primary btn-square mr-2" href="<?php echo e($s['linkedin_url']); ?>" target="_blank" rel="noopener"><i class="fab fa-linkedin-in"></i></a>
                    <?php endif; ?>
                    <?php if(!empty($s['instagram_url'])): ?>
                    <a class="btn btn-primary btn-square mr-2" href="<?php echo e($s['instagram_url']); ?>" target="_blank" rel="noopener"><i class="fab fa-instagram"></i></a>
                    <?php endif; ?>
                    <?php if(!empty($s['youtube_url'])): ?>
                    <a class="btn btn-primary btn-square" href="<?php echo e($s['youtube_url']); ?>" target="_blank" rel="noopener"><i class="fab fa-youtube"></i></a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-8 col-md-12">
                <div class="row">
                    <div class="col-md-4 mb-5">
                        <h5 class="font-weight-bold text-dark mb-4">Quick Links</h5>
                        <div class="d-flex flex-column justify-content-start">
                            <a class="text-dark mb-2" href="<?php echo e(url('/')); ?>"><i class="fa fa-angle-right mr-2"></i>Home</a>
                            <a class="text-dark mb-2" href="<?php echo e(route('products.index')); ?>"><i class="fa fa-angle-right mr-2"></i>Our Shop</a>
                            <a class="text-dark mb-2" href="<?php echo e(route('cart.index')); ?>"><i class="fa fa-angle-right mr-2"></i>Shopping Cart</a>
                            <a class="text-dark mb-2" href="<?php echo e(route('checkout.index')); ?>"><i class="fa fa-angle-right mr-2"></i>Checkout</a>
                            <a class="text-dark mb-2" href="<?php echo e(route('faq')); ?>"><i class="fa fa-angle-right mr-2"></i>FAQs</a>
                            <a class="text-dark mb-2" href="<?php echo e(route('help')); ?>"><i class="fa fa-angle-right mr-2"></i>Help Center</a>
                            <a class="text-dark" href="<?php echo e(route('contact')); ?>"><i class="fa fa-angle-right mr-2"></i>Contact Us</a>
                        </div>
                    </div>
                    <div class="col-md-4 mb-5">
                        <h5 class="font-weight-bold text-dark mb-4">My Account</h5>
                        <div class="d-flex flex-column justify-content-start">
                            <?php if(auth()->guard()->check()): ?>
                            <a class="text-dark mb-2" href="<?php echo e(route('profile.dashboard')); ?>"><i class="fa fa-angle-right mr-2"></i>My Profile</a>
                            <a class="text-dark mb-2" href="<?php echo e(route('profile.orders')); ?>"><i class="fa fa-angle-right mr-2"></i>My Orders</a>
                            <a class="text-dark mb-2" href="<?php echo e(route('profile.reviews')); ?>"><i class="fa fa-angle-right mr-2"></i>My Reviews</a>
                            <a class="text-dark mb-2" href="<?php echo e(route('wishlist.index')); ?>"><i class="fa fa-angle-right mr-2"></i>Wishlist</a>
                            <?php else: ?>
                            <a class="text-dark mb-2" href="<?php echo e(route('customer.login')); ?>"><i class="fa fa-angle-right mr-2"></i>Login</a>
                            <a class="text-dark mb-2" href="<?php echo e(route('customer.register')); ?>"><i class="fa fa-angle-right mr-2"></i>Register</a>
                            <?php endif; ?>
                            <a class="text-dark mb-2" href="<?php echo e(route('faq')); ?>"><i class="fa fa-angle-right mr-2"></i>FAQs</a>
                            <a class="text-dark" href="<?php echo e(route('contact')); ?>"><i class="fa fa-angle-right mr-2"></i>Support</a>
                        </div>
                    </div>
                    <div class="col-md-4 mb-5">
                        <h5 class="font-weight-bold text-dark mb-4">Newsletter</h5>
                        <?php if(session('newsletter_success')): ?>
                            <div class="alert alert-success py-2 small"><?php echo e(session('newsletter_success')); ?></div>
                        <?php endif; ?>
                        <form action="<?php echo e(route('newsletter.subscribe')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input type="text" name="name" class="form-control border-0 py-4"
                                       placeholder="Your Name" value="<?php echo e(old('name')); ?>">
                            </div>
                            <div class="form-group">
                                <input type="email" name="email" class="form-control border-0 py-4 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       placeholder="Your Email *" value="<?php echo e(old('email')); ?>" required>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <button class="btn btn-primary btn-block border-0 py-3" type="submit">Subscribe Now</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row border-top border-light mx-xl-5 py-4">
            <div class="col-md-6 px-xl-0">
                <p class="mb-md-0 text-center text-md-left text-dark">
                    &copy; <?php echo e(date('Y')); ?> <a class="text-dark font-weight-semi-bold" href="<?php echo e(url('/')); ?>">EShopper</a>. All Rights Reserved.
                </p>
            </div>
            <div class="col-md-6 px-xl-0 text-center text-md-right">
                <img class="img-fluid" src="<?php echo e(asset('eshopper/img/payments.png')); ?>" alt="Payment methods">
            </div>
        </div>
    </div>
    <!-- Footer End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('eshopper/lib/easing/easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('eshopper/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('eshopper/js/main.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/prakash/urbandenim/resources/views/front/partials/footer.blade.php ENDPATH**/ ?>