<?php $__env->startSection('title', 'Shopping Cart - EShopper'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('front.partials.page-banner', ['title' => 'Shopping Cart', 'breadcrumb' => 'Shopping Cart'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Cart Start -->
    <div class="container-fluid pt-5">
        <div class="row px-xl-5">

            <?php if(session('success')): ?>
            <div class="col-12">
                <div class="alert alert-success alert-dismissible fade show">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
            </div>
            <?php endif; ?>

            <?php if(empty($cartItems)): ?>
            <div class="col-12 text-center py-5">
                <i class="fas fa-shopping-cart fa-4x text-muted mb-4"></i>
                <h4 class="text-muted">Your cart is empty</h4>
                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary mt-3 px-5">Continue Shopping</a>
            </div>
            <?php else: ?>

            <div class="col-lg-8 table-responsive mb-5">
                <table class="table table-bordered text-center mb-0">
                    <thead class="bg-secondary text-dark">
                        <tr>
                            <th>Products</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Remove</th>
                        </tr>
                    </thead>
                    <tbody class="align-middle">
                        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $product = $item['product']; $price = $product->sale_price ?? $product->price; ?>
                        <tr>
                            <td class="align-middle">
                                <div class="d-flex align-items-center justify-content-center">
                                    <?php if($product->images && $product->images->isNotEmpty()): ?>
                                        <img src="<?php echo e($product->images->first()->url); ?>" alt="" style="width: 50px; height: 50px; object-fit: cover;">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('eshopper/img/product-1.jpg')); ?>" alt="" style="width: 50px;">
                                    <?php endif; ?>
                                    <span class="ml-2"><?php echo e($product->name); ?></span>
                                </div>
                            </td>
                            <td class="align-middle">₹<?php echo e(number_format($price, 2)); ?></td>
                            <td class="align-middle">
                                <div class="input-group quantity mx-auto" style="width: 100px;">
                                    <div class="input-group-btn">
                                        <button class="btn btn-sm btn-primary btn-minus" type="button"><i class="fa fa-minus"></i></button>
                                    </div>
                                    <input type="text" class="form-control form-control-sm bg-secondary text-center qty-input"
                                           value="<?php echo e($item['quantity']); ?>"
                                           data-product="<?php echo e($product->id); ?>"
                                           min="1">
                                    <div class="input-group-btn">
                                        <button class="btn btn-sm btn-primary btn-plus" type="button"><i class="fa fa-plus"></i></button>
                                    </div>
                                </div>
                            </td>
                            <td class="align-middle row-total" data-price="<?php echo e($price); ?>">₹<?php echo e(number_format($price * $item['quantity'], 2)); ?></td>
                            <td class="align-middle">
                                <form method="POST" action="<?php echo e(route('cart.remove')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                    <button type="submit" class="btn btn-sm btn-primary"><i class="fa fa-times"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="col-lg-4">
                <!-- Coupon -->
                <div class="card border-secondary mb-5">
                    <div class="card-header bg-secondary border-0">
                        <h4 class="font-weight-semi-bold m-0">Coupon Code</h4>
                    </div>
                    <div class="card-body">
                        <p>Enter a coupon code to get a discount on your order.</p>
                        <div class="input-group">
                            <input type="text" class="form-control" id="coupon-input" placeholder="Coupon code">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button">Apply</button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Cart Summary -->
                <div class="card border-secondary mb-5">
                    <div class="card-header bg-secondary border-0">
                        <h4 class="font-weight-semi-bold m-0">Cart Summary</h4>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-3 pt-1">
                            <h6 class="font-weight-medium">Subtotal</h6>
                            <h6 class="font-weight-medium" id="cart-subtotal">₹<?php echo e(number_format($subtotal, 2)); ?></h6>
                        </div>
                        <div class="d-flex justify-content-between">
                            <h6 class="font-weight-medium">Shipping</h6>
                            <h6 class="font-weight-medium">
                                <?php if($subtotal >= 500): ?>
                                    <span class="text-success">Free</span>
                                <?php else: ?>
                                    ₹50.00
                                <?php endif; ?>
                            </h6>
                        </div>
                        <?php if($subtotal < 500): ?>
                        <small class="text-muted">Free shipping on orders above ₹500</small>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer border-secondary bg-transparent">
                        <div class="d-flex justify-content-between mt-2">
                            <h5 class="font-weight-bold">Total</h5>
                            <h5 class="font-weight-bold" id="cart-total">₹<?php echo e(number_format($subtotal + ($subtotal >= 500 ? 0 : 50), 2)); ?></h5>
                        </div>
                        <a href="<?php echo e(route('checkout.index')); ?>" class="btn btn-block btn-primary my-3 py-3 font-weight-bold">
                            Proceed To Checkout
                        </a>
                        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-block btn-outline-dark py-3">
                            Continue Shopping
                        </a>
                    </div>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
    <!-- Cart End -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function updateCartQty(productId, qty) {
    $.post('<?php echo e(route("cart.update")); ?>', {
        _token: '<?php echo e(csrf_token()); ?>',
        product_id: productId,
        quantity: qty
    }, function(data) {
        if (data.success) {
            $('#cart-count').text(data.cart_count);
            // Reload to recalculate totals accurately
            location.reload();
        }
    });
}

$(document).on('click', '.btn-plus', function() {
    var $input = $(this).closest('.quantity').find('.qty-input');
    var val = parseInt($input.val()) || 1;
    var newVal = val + 1;
    $input.val(newVal);
    updateCartQty($input.data('product'), newVal);
});

$(document).on('click', '.btn-minus', function() {
    var $input = $(this).closest('.quantity').find('.qty-input');
    var val = parseInt($input.val()) || 1;
    if (val > 1) {
        var newVal = val - 1;
        $input.val(newVal);
        updateCartQty($input.data('product'), newVal);
    }
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.eshopper', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/prakash/urbandenim/resources/views/front/cart.blade.php ENDPATH**/ ?>