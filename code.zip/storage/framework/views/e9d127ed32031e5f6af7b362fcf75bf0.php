<?php $__env->startSection('title', 'Product Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-title d-flex justify-content-between align-items-center">
    <h2><i class="fas fa-box"></i> <?php echo e($product->name); ?></h2>
    <div class="btn-group">
        <a href="<?php echo e(route('admin.products.edit', $product)); ?>" class="btn btn-warning">
            <i class="fas fa-edit"></i> Edit
        </a>
        <form action="<?php echo e(route('admin.products.destroy', $product)); ?>" method="POST" style="display:inline;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">
                <i class="fas fa-trash"></i> Delete
            </button>
        </form>
        <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back
        </a>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <!-- Product Information -->
        <div class="card mb-4">
            <div class="card-header">
                <span>Product Information</span>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <strong>Product Name:</strong>
                        <p><?php echo e($product->name); ?></p>
                    </div>
                    <div class="col-md-6">
                        <strong>SKU:</strong>
                        <p><code><?php echo e($product->sku ?? 'N/A'); ?></code></p>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <strong>Slug:</strong>
                        <p><code><?php echo e($product->slug); ?></code></p>
                    </div>
                    <div class="col-md-6">
                        <strong>Status:</strong>
                        <p>
                            <?php if($product->is_active): ?>
                                <span class="badge bg-success">Active</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Inactive</span>
                            <?php endif; ?>
                            <?php if($product->is_featured): ?>
                                <span class="badge bg-warning"><i class="fas fa-star"></i> Featured</span>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>

                <div class="mb-3">
                    <strong>Short Description:</strong>
                    <p><?php echo e($product->short_description ?? 'N/A'); ?></p>
                </div>

                <div class="mb-3">
                    <strong>Description:</strong>
                    <p><?php echo e($product->description ?? 'N/A'); ?></p>
                </div>
            </div>
        </div>

        <!-- Categorization -->
        <div class="card mb-4">
            <div class="card-header">
                <span>Categorization</span>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <strong>Category:</strong>
                        <?php if($product->category): ?>
                            <p><span class="badge bg-info"><?php echo e($product->category->name); ?></span></p>
                        <?php else: ?>
                            <p><span class="text-muted">Not assigned</span></p>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <strong>Brand:</strong>
                        <?php if($product->brand): ?>
                            <p><span class="badge bg-secondary"><?php echo e($product->brand->name); ?></span></p>
                        <?php else: ?>
                            <p><span class="text-muted">Not assigned</span></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pricing -->
        <div class="card mb-4">
            <div class="card-header">
                <span>Pricing</span>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <strong>Regular Price:</strong>
                        <p class="h5 text-primary">₹<?php echo e(number_format($product->price, 2)); ?></p>
                    </div>
                    <div class="col-md-6">
                        <strong>Sale Price:</strong>
                        <?php if($product->sale_price): ?>
                            <p class="h5 text-success">₹<?php echo e(number_format($product->sale_price, 2)); ?></p>
                            <small class="text-muted">Discount: ₹<?php echo e(number_format($product->price - $product->sale_price, 2)); ?></small>
                        <?php else: ?>
                            <p class="text-muted">Not set</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Attributes -->
        <div class="card mb-4">
            <div class="card-header">
                <span>Attributes</span>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3">
                        <strong>Gender:</strong>
                        <p><?php echo e($product->gender ? ucfirst($product->gender) : 'N/A'); ?></p>
                    </div>
                    <div class="col-md-3">
                        <strong>Age Group:</strong>
                        <p><?php echo e($product->age_group ? ucfirst($product->age_group) : 'N/A'); ?></p>
                    </div>
                    <div class="col-md-3">
                        <strong>Fit Type:</strong>
                        <p><?php echo e($product->fit_type ? ucfirst($product->fit_type) : 'N/A'); ?></p>
                    </div>
                    <div class="col-md-3">
                        <strong>Color Family:</strong>
                        <p><?php echo e($product->color_family ? ucfirst($product->color_family) : 'N/A'); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Metadata -->
        <div class="card">
            <div class="card-header">
                <span>Metadata</span>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <strong>Created:</strong>
                        <p><?php echo e($product->created_at->format('M d, Y H:i')); ?></p>
                    </div>
                    <div class="col-md-6">
                        <strong>Last Updated:</strong>
                        <p><?php echo e($product->updated_at->format('M d, Y H:i')); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <!-- Statistics -->
        <div class="card mb-4">
            <div class="card-header">
                <span>Statistics</span>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <span>Total Variants:</span>
                        <strong class="badge bg-primary"><?php echo e($variants->count()); ?></strong>
                    </div>
                </div>
                <div class="mb-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <span>Total Stock:</span>
                        <?php $totalStock = $variants->sum('quantity'); ?>
                        <strong class="badge <?php if($totalStock > 0): ?> bg-success <?php else: ?> bg-danger <?php endif; ?>">
                            <?php echo e($totalStock); ?>

                        </strong>
                    </div>
                </div>
                <div class="mb-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <span>Images:</span>
                        <strong class="badge bg-info"><?php echo e($images->count()); ?></strong>
                    </div>
                </div>
            </div>
        </div>

        <!-- Variants -->
        <?php if($variants->count() > 0): ?>
            <div class="card mb-4">
                <div class="card-header">
                    <span>Variants (<?php echo e($variants->count()); ?>)</span>
                </div>
                <div class="list-group list-group-flush">
                    <?php $__currentLoopData = $variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="list-group-item">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <h6 class="mb-1">
                                        Size: <strong><?php echo e($variant->waist_size); ?></strong> | 
                                        Color: <strong><?php echo e($variant->color); ?></strong>
                                    </h6>
                                    <small class="text-muted">SKU: <?php echo e($variant->sku); ?></small>
                                    <br>
                                    <small class="text-muted">Price: ₹<?php echo e($variant->price); ?></small>
                                </div>
                                <span class="badge <?php if($variant->quantity > 0): ?> bg-success <?php else: ?> bg-danger <?php endif; ?>">
                                    <?php echo e($variant->quantity); ?> in stock
                                </span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Images -->
        <?php if($images->count() > 0): ?>
            <div class="card">
                <div class="card-header">
                    <span>Images (<?php echo e($images->count()); ?>)</span>
                </div>
                <div class="card-body">
                    <div class="d-flex flex-wrap gap-2">
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="text-center">
                                <img src="<?php echo e($image->url); ?>"
                                     alt="<?php echo e($product->name); ?>"
                                     style="width:80px; height:80px; object-fit:cover; border-radius:4px; border:1px solid #dee2e6;">
                                <br>
                                <small class="text-muted"><?php echo e($image->sort_order); ?></small>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/prakash/urbandenim/resources/views/admin/products/show.blade.php ENDPATH**/ ?>