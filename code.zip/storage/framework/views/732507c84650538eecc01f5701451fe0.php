<?php $__env->startSection('title', 'My Orders - EShopper'); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('front.partials.page-banner', ['title' => 'My Orders', 'breadcrumb' => 'My Orders'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container-fluid pt-5 pb-5">
    <div class="row px-xl-5">
        <?php echo $__env->make('front.partials.profile-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="col-lg-9 mb-5">
            <h5 class="font-weight-semi-bold mb-4">Order History</h5>

            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show"><?php echo e(session('success')); ?><button type="button" class="close" data-dismiss="alert">&times;</button></div>
            <?php endif; ?>

            <?php if($orders->isEmpty()): ?>
                <div class="text-center py-5 bg-light rounded">
                    <i class="fa fa-shopping-bag fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">No orders yet</h5>
                    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary mt-3">Start Shopping</a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered text-center">
                        <thead class="bg-secondary">
                            <tr>
                                <th>Order #</th><th>Date</th><th>Items</th><th>Total</th><th>Status</th><th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $bm = ['pending'=>'warning','processing'=>'info','shipped'=>'primary','delivered'=>'success','cancelled'=>'danger'];
                                $badge = $bm[$order->status] ?? 'secondary';
                                $cancellable = in_array($order->status, ['pending','processing']);
                            ?>
                            <tr>
                                <td><strong>#<?php echo e($order->id); ?></strong></td>
                                <td><?php echo e($order->created_at->format('d M Y')); ?></td>
                                <td><span class="badge badge-info"><?php echo e($order->products->count()); ?> items</span></td>
                                <td>₹<?php echo e(number_format($order->total_price, 2)); ?></td>
                                <td><span class="badge badge-<?php echo e($badge); ?> text-capitalize"><?php echo e($order->status); ?></span></td>
                                <td>
                                    <div class="d-flex justify-content-center flex-wrap gap-1">
                                        <a href="<?php echo e(route('profile.order-details', $order->id)); ?>" class="btn btn-sm btn-outline-primary">View</a>
                                        
                                        <form method="POST" action="<?php echo e(route('profile.reorder', $order->id)); ?>" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-success" title="Add all items to cart again">
                                                <i class="fa fa-redo mr-1"></i>Reorder
                                            </button>
                                        </form>
                                        
                                        <?php if($cancellable): ?>
                                            <button type="button" class="btn btn-sm btn-outline-danger"
                                                    data-toggle="modal" data-target="#cancelModal<?php echo e($order->id); ?>">Cancel</button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>

                            <?php if($cancellable): ?>
                            <div class="modal fade" id="cancelModal<?php echo e($order->id); ?>" tabindex="-1" role="dialog">
                                <div class="modal-dialog"><div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title text-danger">Cancel Order #<?php echo e($order->id); ?></h5>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>
                                    <form method="POST" action="<?php echo e(route('profile.cancel-order', $order->id)); ?>">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <div class="modal-body">
                                            <p>Are you sure you want to cancel <strong>Order #<?php echo e($order->id); ?></strong>?</p>
                                            <select class="form-control" name="reason">
                                                <option value="">-- Select a reason --</option>
                                                <option>Changed my mind</option>
                                                <option>Ordered by mistake</option>
                                                <option>Found a better price elsewhere</option>
                                                <option>Delivery time is too long</option>
                                                <option>Other</option>
                                            </select>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Keep Order</button>
                                            <button type="submit" class="btn btn-danger">Cancel Order</button>
                                        </div>
                                    </form>
                                </div></div>
                            </div>
                            <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="mt-3"><?php echo e($orders->links()); ?></div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.eshopper', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/prakash/urbandenim/resources/views/front/profile/orders.blade.php ENDPATH**/ ?>