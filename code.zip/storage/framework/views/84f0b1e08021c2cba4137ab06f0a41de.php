<?php $__env->startSection('title', 'Shop - EShopper'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('front.partials.page-banner', ['title' => 'Our Shop', 'breadcrumb' => 'Shop'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Shop Start -->
    <div class="container-fluid pt-5">
        <div class="row px-xl-5">

            <!-- Sidebar Start -->
            <div class="col-lg-3 col-md-12">

                <!-- Categories -->
                <div class="border-bottom mb-4 pb-4">
                    <h5 class="font-weight-semi-bold mb-4">Filter by Category</h5>
                    <div class="d-flex flex-column">
                        <a href="<?php echo e(route('products.index')); ?>" class="mb-2 <?php echo e(!request('category') ? 'text-primary font-weight-bold' : 'text-dark'); ?>">
                            All Categories
                        </a>
                        <?php $__currentLoopData = \App\Models\Category::where('is_active',true)->withCount('products')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('products.index', array_merge(request()->except('page'), ['category' => $cat->id]))); ?>"
                           class="d-flex justify-content-between mb-2 <?php echo e(request('category') == $cat->id ? 'text-primary font-weight-bold' : 'text-dark'); ?>">
                            <span><?php echo e($cat->name); ?></span>
                            <span class="badge border font-weight-normal"><?php echo e($cat->products_count); ?></span>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <!-- Price Filter -->
                <div class="border-bottom mb-4 pb-4">
                    <h5 class="font-weight-semi-bold mb-4">Filter by price</h5>
                    <form method="GET" action="<?php echo e(route('products.index')); ?>">
                        <?php $__currentLoopData = request()->except(['price_min','price_max','page']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="<?php echo e($k); ?>" value="<?php echo e($v); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $priceRanges = [
                                '' => ['label' => 'All Price', 'min' => '', 'max' => ''],
                                '0-500' => ['label' => '₹0 - ₹500', 'min' => 0, 'max' => 500],
                                '500-1000' => ['label' => '₹500 - ₹1000', 'min' => 500, 'max' => 1000],
                                '1000-2000' => ['label' => '₹1000 - ₹2000', 'min' => 1000, 'max' => 2000],
                                '2000-5000' => ['label' => '₹2000 - ₹5000', 'min' => 2000, 'max' => 5000],
                                '5000+' => ['label' => '₹5000+', 'min' => 5000, 'max' => ''],
                            ];
                            $currentRange = request('price_min','') . '-' . request('price_max','');
                        ?>
                        <?php $__currentLoopData = $priceRanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $range): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
                            <input type="radio" class="custom-control-input" id="price-<?php echo e($loop->index); ?>"
                                   name="price_range" value="<?php echo e($key); ?>"
                                   <?php echo e((request('price_min','').'-'.request('price_max','')) == $key || ($key === '' && !request('price_min')) ? 'checked' : ''); ?>

                                   onchange="this.form.submit()">
                            <label class="custom-control-label" for="price-<?php echo e($loop->index); ?>"><?php echo e($range['label']); ?></label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </form>
                </div>

                <!-- Brand Filter -->
                <?php $brands = \App\Models\Brand::has('products')->take(8)->get(); ?>
                <?php if($brands->isNotEmpty()): ?>
                <div class="mb-5">
                    <h5 class="font-weight-semi-bold mb-4">Filter by Brand</h5>
                    <div class="d-flex flex-column">
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('products.index', array_merge(request()->except(['brand','page']), ['brand' => $brand->id]))); ?>"
                           class="mb-2 <?php echo e(request('brand') == $brand->id ? 'text-primary font-weight-bold' : 'text-dark'); ?>">
                            <?php echo e($brand->name); ?>

                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <!-- Sidebar End -->

            <!-- Products Start -->
            <div class="col-lg-9 col-md-12">
                <div class="row pb-3">
                    <div class="col-12 pb-1">
                        <div class="d-flex align-items-center justify-content-between mb-4">
                            <form action="<?php echo e(route('products.index')); ?>" method="GET" class="flex-grow-1 mr-3">
                                <?php $__currentLoopData = request()->except(['search','page']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="<?php echo e($k); ?>" value="<?php echo e($v); ?>">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="input-group">
                                    <input type="text" name="search" class="form-control" placeholder="Search by name" value="<?php echo e(request('search')); ?>">
                                    <div class="input-group-append">
                                        <button type="submit" class="input-group-text bg-transparent text-primary" style="cursor:pointer;">
                                            <i class="fa fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                            <div class="dropdown ml-4">
                                <button class="btn border dropdown-toggle" type="button" data-toggle="dropdown">
                                    Sort by: <?php echo e(request('sort','Latest')); ?>

                                </button>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="<?php echo e(route('products.index', array_merge(request()->except('sort'), ['sort' => 'latest']))); ?>">Latest</a>
                                    <a class="dropdown-item" href="<?php echo e(route('products.index', array_merge(request()->except('sort'), ['sort' => 'price_asc']))); ?>">Price: Low to High</a>
                                    <a class="dropdown-item" href="<?php echo e(route('products.index', array_merge(request()->except('sort'), ['sort' => 'price_desc']))); ?>">Price: High to Low</a>
                                    <a class="dropdown-item" href="<?php echo e(route('products.index', array_merge(request()->except('sort'), ['sort' => 'name_asc']))); ?>">Name A-Z</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-4 col-md-6 col-sm-12 pb-1">
                        <div class="card product-item border-0 mb-4">
                            <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                                <?php if($product->images && $product->images->isNotEmpty()): ?>
                                    <?php
                                        $img = $product->images->first();
                                        $relativePath = 'products/' . $product->id . '/images/' . ($img->image ?? '');
                                        $publicUrl = asset('storage/' . $relativePath);
                                        $fallbackUrl = asset('storage/default.jpeg');
                                    ?>
                                    <img class="img-fluid w-100" src="<?php echo e(file_exists(public_path('storage/' . $relativePath)) ? $publicUrl : $fallbackUrl); ?>" alt="<?php echo e($product->name); ?>">
                                <?php else: ?>
                                    <img class="img-fluid w-100" src="<?php echo e(asset('eshopper/img/product-1.jpg')); ?>" alt="<?php echo e($product->name); ?>">
                                <?php endif; ?>
                            </div>
                            <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                                <h6 class="text-truncate mb-3"><?php echo e($product->name); ?></h6>
                                <div class="d-flex justify-content-center">
                                    <h6>₹<?php echo e(number_format($product->sale_price ?? $product->price, 2)); ?></h6>
                                    <?php if($product->sale_price && $product->sale_price < $product->price): ?>
                                        <h6 class="text-muted ml-2"><del>₹<?php echo e(number_format($product->price, 2)); ?></del></h6>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="card-footer d-flex justify-content-between bg-light border">
                                <a href="<?php echo e(route('products.detail', $product->slug)); ?>" class="btn btn-sm text-dark p-0">
                                    <i class="fas fa-eye text-primary mr-1"></i>View Detail
                                </a>
                                <form method="POST" action="<?php echo e(route('cart.add')); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                    <input type="hidden" name="quantity" value="1">
                                    <button type="submit" class="btn btn-sm text-dark p-0">
                                        <i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12 text-center py-5">
                        <i class="fas fa-search fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No products found</h5>
                        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary mt-3">Clear Filters</a>
                    </div>
                    <?php endif; ?>

                    <!-- Pagination -->
                    <?php if($products->hasPages()): ?>
                    <div class="col-12 pb-1">
                        <nav>
                            <ul class="pagination justify-content-center mb-3">
                                
                                <li class="page-item <?php echo e($products->onFirstPage() ? 'disabled' : ''); ?>">
                                    <a class="page-link" href="<?php echo e($products->previousPageUrl()); ?>">Previous</a>
                                </li>
                                <?php $__currentLoopData = $products->getUrlRange(1, $products->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="page-item <?php echo e($products->currentPage() == $page ? 'active' : ''); ?>">
                                    <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li class="page-item <?php echo e($products->hasMorePages() ? '' : 'disabled'); ?>">
                                    <a class="page-link" href="<?php echo e($products->nextPageUrl()); ?>">Next</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <!-- Products End -->

        </div>
    </div>
    <!-- Shop End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.eshopper', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/prakash/urbandenim/resources/views/front/products.blade.php ENDPATH**/ ?>