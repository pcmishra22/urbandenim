<?php $__env->startSection('title', 'Products Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-title d-flex justify-content-between align-items-center">
    <h2><i class="fas fa-box"></i> Products Management</h2>
    <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus"></i> Add New Product
    </a>
</div>

<!-- Search & Filter -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-3">
                <input type="text" name="search" class="form-control" placeholder="Search products..." value="<?php echo e(request('search')); ?>">
            </div>

            <div class="col-md-2">
                <select name="category_id" class="form-select">
                    <option value="">-- All Categories --</option>
                    <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>" <?php if(request('category_id') == $cat->id): echo 'selected'; endif; ?>><?php echo e($cat->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-2">
                <select name="brand_id" class="form-select">
                    <option value="">-- All Brands --</option>
                    <?php $__currentLoopData = \App\Models\Brand::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($brand->id); ?>" <?php if(request('brand_id') == $brand->id): echo 'selected'; endif; ?>><?php echo e($brand->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-2">
                <select name="fit_type" class="form-select">
                    <option value="">-- All Fit Types --</option>
                    <?php $__currentLoopData = ['Slim','Regular','Relaxed','Oversized']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($fit); ?>" <?php if(request('fit_type') === $fit): echo 'selected'; endif; ?>><?php echo e($fit); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-3">
                <input type="text" name="color" class="form-control" placeholder="Color (family)" value="<?php echo e(request('color')); ?>">
            </div>

            <div class="col-md-2">
                <input type="number" step="0.01" name="price_min" class="form-control" placeholder="Min price" value="<?php echo e(request('price_min')); ?>">
            </div>

            <div class="col-md-2">
                <input type="number" step="0.01" name="price_max" class="form-control" placeholder="Max price" value="<?php echo e(request('price_max')); ?>">
            </div>

            <div class="col-md-2">
                <input type="text" name="size" class="form-control" placeholder="Size (variant)" value="<?php echo e(request('size')); ?>">
            </div>

            <div class="col-md-2">
                <button type="submit" class="btn btn-outline-secondary w-100">
                    <i class="fas fa-search"></i> Filter
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Products Table -->
<div class="card">
    <div class="card-header">
        <span>All Products (<?php echo e($products->total()); ?>)</span>
    </div>
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Product Name</th>
                    <th>Category</th>
                    <th>Brand</th>
                    <th>Price</th>
                    <th>Sale Price</th>
                    <th>Stock</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><strong>#<?php echo e($product->id); ?></strong></td>
                        <td>
                            <div>
                                <strong><?php echo e($product->name); ?></strong>
                                <br>
                                <small class="text-muted">SKU: <?php echo e($product->sku ?? 'N/A'); ?></small>
                            </div>
                        </td>
                        <td>
                            <?php if($product->category): ?>
                                <span class="badge bg-info"><?php echo e($product->category->name); ?></span>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($product->brand): ?>
                                <span class="badge bg-secondary"><?php echo e($product->brand->name); ?></span>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong>₹<?php echo e(number_format($product->price, 2)); ?></strong>
                        </td>
                        <td>
                            <?php if($product->sale_price): ?>
                                <strong class="text-success">₹<?php echo e(number_format($product->sale_price, 2)); ?></strong>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php $stock = $product->variants()->sum('quantity'); ?>
                            <span class="badge <?php if($stock > 0): ?> bg-success <?php else: ?> bg-danger <?php endif; ?>">
                                <?php echo e($stock); ?>

                            </span>
                        </td>
                        <td>
                            <?php if($product->is_active): ?>
                                <span class="badge bg-success">Active</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('admin.products.show', $product)); ?>" class="btn btn-sm btn-info" title="View">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?php echo e(route('admin.products.edit', $product)); ?>" class="btn btn-sm btn-warning" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('admin.products.destroy', $product)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" title="Delete" onclick="return confirm('Are you sure?')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" class="text-center text-muted py-4">
                            <i class="fas fa-inbox"></i> No products found
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Pagination -->
<div class="d-flex justify-content-center mt-4">
    <?php echo e($products->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/prakash/urbandenim/resources/views/admin/products/index.blade.php ENDPATH**/ ?>