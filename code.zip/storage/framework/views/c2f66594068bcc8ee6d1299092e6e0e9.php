<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title', 'EShopper'); ?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link href="<?php echo e(asset('eshopper/img/favicon.ico')); ?>" rel="icon">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('eshopper/lib/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('eshopper/css/style.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <!-- Topbar Start -->
    <div class="container-fluid">
        <div class="row bg-secondary py-2 px-xl-5">
            <div class="col-lg-6 d-none d-lg-block">
                <div class="d-inline-flex align-items-center">
                    <a class="text-dark" href="#">FAQs</a>
                    <span class="text-muted px-2">|</span>
                    <a class="text-dark" href="#">Help</a>
                    <span class="text-muted px-2">|</span>
                    <a class="text-dark" href="<?php echo e(route('contact')); ?>">Support</a>
                </div>
            </div>
            <div class="col-lg-6 text-center text-lg-right">
                <div class="d-inline-flex align-items-center">
                    <a class="text-dark px-2" href="#"><i class="fab fa-facebook-f"></i></a>
                    <a class="text-dark px-2" href="#"><i class="fab fa-twitter"></i></a>
                    <a class="text-dark px-2" href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a class="text-dark px-2" href="#"><i class="fab fa-instagram"></i></a>
                    <a class="text-dark pl-2" href="#"><i class="fab fa-youtube"></i></a>
                </div>
            </div>
        </div>
        <div class="row align-items-center py-3 px-xl-5">
            <div class="col-lg-3 d-none d-lg-block">
                <a href="<?php echo e(url('/')); ?>" class="text-decoration-none">
                    <h1 class="m-0 display-5 font-weight-semi-bold"><span class="text-primary font-weight-bold border px-3 mr-1">E</span>Shopper</h1>
                </a>
            </div>
            <div class="col-lg-6 col-6 text-left">
                <form action="<?php echo e(route('products.index')); ?>" method="GET">
                    <div class="input-group">
                        <input type="text" name="search" class="form-control" placeholder="Search for products" value="<?php echo e(request('search')); ?>">
                        <div class="input-group-append">
                            <button type="submit" class="input-group-text bg-transparent text-primary border-left-0" style="cursor:pointer;border:1px solid #ced4da;">
                                <i class="fa fa-search"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-lg-3 col-6 text-right">
                <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('wishlist.index')); ?>" class="btn border">
                    <i class="fas fa-heart text-primary"></i>
                    <span class="badge"><?php echo e($headerWishlistCount ?? 0); ?></span>
                </a>
                <?php endif; ?>
                <a href="<?php echo e(route('cart.index')); ?>" class="btn border">
                    <i class="fas fa-shopping-cart text-primary"></i>
                    <span class="badge" id="cart-count"><?php echo e($headerCartCount ?? 0); ?></span>
                </a>
            </div>
        </div>
    </div>
    <!-- Topbar End -->

    <!-- Navbar Start -->
    <div class="container-fluid mb-5">
        <div class="row border-top px-xl-5">
            <div class="col-lg-3 d-none d-lg-block">
                <a class="btn shadow-none d-flex align-items-center justify-content-between bg-primary text-white w-100"
                   data-toggle="collapse" href="#navbar-vertical" style="height: 65px; margin-top: -1px; padding: 0 30px;">
                    <h6 class="m-0">Categories</h6>
                    <i class="fa fa-angle-down text-dark"></i>
                </a>
                <nav class="collapse show navbar navbar-vertical navbar-light align-items-start p-0 border border-top-0 border-bottom-0" id="navbar-vertical">
                    <div class="navbar-nav w-100 overflow-hidden" style="height: 410px">
                        <?php $navCategories = \App\Models\Category::where('is_active', true)->take(10)->get(); ?>
                        <?php $__empty_1 = true; $__currentLoopData = $navCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <a href="<?php echo e(route('products.index', ['category' => $cat->id])); ?>" class="nav-item nav-link"><?php echo e($cat->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <a href="<?php echo e(route('products.index')); ?>" class="nav-item nav-link">All Products</a>
                        <?php endif; ?>
                    </div>
                </nav>
            </div>
            <div class="col-lg-9">
                <nav class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0">
                    <a href="<?php echo e(url('/')); ?>" class="text-decoration-none d-block d-lg-none">
                        <h1 class="m-0 display-5 font-weight-semi-bold"><span class="text-primary font-weight-bold border px-3 mr-1">E</span>Shopper</h1>
                    </a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto py-0">
                            <a href="<?php echo e(url('/')); ?>" class="nav-item nav-link <?php echo e(request()->is('/') ? 'active' : ''); ?>">Home</a>
                            <a href="<?php echo e(route('products.index')); ?>" class="nav-item nav-link <?php echo e(request()->routeIs('products.*') ? 'active' : ''); ?>">Shop</a>
                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Pages</a>
                                <div class="dropdown-menu rounded-0 m-0">
                                    <a href="<?php echo e(route('cart.index')); ?>" class="dropdown-item">Shopping Cart</a>
                                    <a href="<?php echo e(route('checkout.index')); ?>" class="dropdown-item">Checkout</a>
                                    <?php if(auth()->guard()->check()): ?>
                                    <a href="<?php echo e(route('profile.dashboard')); ?>" class="dropdown-item">My Account</a>
                                    <a href="<?php echo e(route('profile.orders')); ?>" class="dropdown-item">My Orders</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <a href="<?php echo e(route('contact')); ?>" class="nav-item nav-link <?php echo e(request()->routeIs('contact') ? 'active' : ''); ?>">Contact</a>
                        </div>
                        <div class="navbar-nav ml-auto py-0">
                            <?php if(auth()->guard()->guest()): ?>
                                <a href="<?php echo e(route('customer.login')); ?>" class="nav-item nav-link">Login</a>
                                <a href="<?php echo e(route('customer.register')); ?>" class="nav-item nav-link">Register</a>
                            <?php else: ?>
                                <div class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                                        <i class="fa fa-user-circle mr-1"></i><?php echo e(auth()->user()->name); ?>

                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right rounded-0 m-0">
                                        <a href="<?php echo e(route('profile.dashboard')); ?>" class="dropdown-item">My Account</a>
                                        <a href="<?php echo e(route('profile.orders')); ?>" class="dropdown-item">My Orders</a>
                                        <a href="<?php echo e(route('wishlist.index')); ?>" class="dropdown-item">Wishlist</a>
                                        <div class="dropdown-divider"></div>
                                        <form method="POST" action="<?php echo e(route('customer.logout')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="dropdown-item text-danger">Logout</button>
                                        </form>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </nav>
                <?php echo $__env->yieldContent('navbar-extra'); ?>
            </div>
        </div>
    </div>
    <!-- Navbar End -->
<?php /**PATH /home/prakash/urbandenim/resources/views/front/partials/header.blade.php ENDPATH**/ ?>