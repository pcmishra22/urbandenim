<?php $__env->startSection('title', 'Order #' . $order->id . ' - EShopper'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('front.partials.page-banner', ['title' => 'Order Details', 'breadcrumb' => 'Order #' . $order->id], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="container-fluid pt-5 pb-5">
        <div class="row px-xl-5">
            <?php echo $__env->make('front.partials.profile-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="col-lg-9 mb-5">

                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                    </div>
                <?php endif; ?>

                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h5 class="font-weight-semi-bold m-0">Order #<?php echo e($order->id); ?></h5>
                    <a href="<?php echo e(route('profile.orders')); ?>" class="btn btn-outline-dark btn-sm">
                        <i class="fa fa-arrow-left mr-2"></i>Back to Orders
                    </a>
                </div>

                
                <?php
                    $badgeMap = ['pending'=>'warning','processing'=>'info','shipped'=>'primary','delivered'=>'success','cancelled'=>'danger'];
                    $badge = $badgeMap[$order->status] ?? 'secondary';
                    $cancellable = in_array($order->status, ['pending','processing']);
                ?>

                <div class="bg-light rounded p-4 mb-4">
                    <div class="row">
                        <div class="col-6 col-md-3 mb-3">
                            <small class="text-muted d-block">Order #</small>
                            <strong>#<?php echo e($order->id); ?></strong>
                        </div>
                        <div class="col-6 col-md-3 mb-3">
                            <small class="text-muted d-block">Date</small>
                            <strong><?php echo e($order->created_at->format('d M Y')); ?></strong>
                        </div>
                        <div class="col-6 col-md-3 mb-3">
                            <small class="text-muted d-block">Total</small>
                            <strong>₹<?php echo e(number_format($order->total_price, 2)); ?></strong>
                        </div>
                        <div class="col-6 col-md-3 mb-3">
                            <small class="text-muted d-block">Status</small>
                            <span class="badge badge-<?php echo e($badge); ?> text-capitalize"><?php echo e($order->status); ?></span>
                        </div>
                        <div class="col-6 col-md-3 mb-2">
                            <small class="text-muted d-block">Payment</small>
                            <strong>
                                <?php if($order->payment_method==='cod'): ?> Cash on Delivery
                                <?php elseif($order->payment_method==='upi'): ?> UPI / Net Banking
                                <?php else: ?> Card <?php endif; ?>
                            </strong>
                        </div>
                        <div class="col-6 col-md-3 mb-2">
                            <small class="text-muted d-block">Payment Status</small>
                            <span class="badge <?php echo e(($order->payment_status==='paid') ? 'badge-success' : 'badge-warning'); ?> text-capitalize">
                                <?php echo e($order->payment_status ?? 'pending'); ?>

                            </span>
                        </div>
                    </div>
                </div>

                
                <?php if($order->products && $order->products->count() > 0): ?>
                <div class="mb-4">
                    <h6 class="font-weight-semi-bold mb-3">Items Ordered</h6>
                    <div class="table-responsive">
                        <table class="table table-bordered text-center">
                            <thead class="bg-secondary">
                                <tr>
                                    <th class="text-left">Product</th>
                                    <th>Qty</th>
                                    <th>Price</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-left align-middle">
                                        <div class="d-flex align-items-center">
                                            <?php if($product->images && $product->images->isNotEmpty()): ?>
                                                <img src="<?php echo e($product->images->first()->url); ?>" alt="<?php echo e($product->name); ?>"
                                                     style="width:45px;height:45px;object-fit:cover;border-radius:4px;margin-right:10px;">
                                            <?php endif; ?>
                                            <?php echo e($product->name); ?>

                                        </div>
                                    </td>
                                    <td class="align-middle"><?php echo e($product->pivot->quantity); ?></td>
                                    <td class="align-middle">₹<?php echo e(number_format($product->pivot->price, 2)); ?></td>
                                    <td class="align-middle">₹<?php echo e(number_format($product->pivot->quantity * $product->pivot->price, 2)); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot class="bg-light">
                                <?php if($order->subtotal): ?>
                                <tr><td colspan="3" class="text-right">Subtotal</td><td>₹<?php echo e(number_format($order->subtotal,2)); ?></td></tr>
                                <?php endif; ?>
                                <tr><td colspan="3" class="text-right">Shipping</td>
                                    <td><?php if(!$order->shipping_cost): ?><span class="text-success">Free</span><?php else: ?> ₹<?php echo e(number_format($order->shipping_cost,2)); ?><?php endif; ?></td></tr>
                                <?php if($order->discount_amount > 0): ?>
                                <tr><td colspan="3" class="text-right text-success">Discount <?php if($order->coupon_code): ?><small>(<?php echo e($order->coupon_code); ?>)</small><?php endif; ?></td>
                                    <td class="text-success">- ₹<?php echo e(number_format($order->discount_amount,2)); ?></td></tr>
                                <?php endif; ?>
                                <tr><td colspan="3" class="text-right font-weight-bold">Total</td>
                                    <td class="font-weight-bold">₹<?php echo e(number_format($order->total_price,2)); ?></td></tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
                <?php endif; ?>

                
                <?php if($order->shipping_full_name): ?>
                <div class="bg-light rounded p-4 mb-4">
                    <h6 class="font-weight-semi-bold mb-3">Shipping Address</h6>
                    <p class="mb-1"><strong><?php echo e($order->shipping_full_name); ?></strong></p>
                    <p class="mb-1"><?php echo e($order->shipping_street); ?></p>
                    <p class="mb-1"><?php echo e($order->shipping_city); ?>, <?php echo e($order->shipping_state); ?> — <?php echo e($order->shipping_postal_code); ?></p>
                    <p class="mb-1"><?php echo e($order->shipping_country); ?></p>
                    <p class="mb-0"><i class="fa fa-phone mr-1 text-muted"></i><?php echo e($order->shipping_phone); ?></p>
                    <?php if($order->notes): ?><hr><p class="mb-0 text-muted"><i class="fa fa-sticky-note mr-1"></i><?php echo e($order->notes); ?></p><?php endif; ?>
                </div>
                <?php endif; ?>

                
                <?php if($order->shipments && $order->shipments->count() > 0): ?>
                <div class="bg-light rounded p-4 mb-4">
                    <h6 class="font-weight-semi-bold mb-3">Shipment Tracking</h6>
                    <?php $__currentLoopData = $order->shipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="mb-1"><strong>Courier:</strong> <?php echo e($shipment->courier->name ?? 'N/A'); ?></p>
                    <p class="mb-1"><strong>Tracking #:</strong> <?php echo e($shipment->tracking_number ?? 'Not available yet'); ?></p>
                    <p class="mb-0"><strong>Status:</strong> <?php echo e(ucfirst($shipment->status ?? 'Pending')); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>

                
                <?php if($cancellable): ?>
                <div class="border border-danger rounded p-4 mb-4">
                    <h6 class="font-weight-semi-bold text-danger mb-2"><i class="fa fa-times-circle mr-1"></i>Cancel This Order</h6>
                    <p class="text-muted small mb-3">You can cancel this order while it's still <strong><?php echo e($order->status); ?></strong>. Once shipped, cancellation is no longer possible.</p>
                    <button type="button" class="btn btn-outline-danger btn-sm" data-toggle="modal" data-target="#cancelModal">
                        Cancel Order
                    </button>
                </div>

                <!-- Cancel Modal -->
                <div class="modal fade" id="cancelModal" tabindex="-1" role="dialog">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title text-danger"><i class="fa fa-exclamation-triangle mr-1"></i> Cancel Order #<?php echo e($order->id); ?></h5>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                            <form method="POST" action="<?php echo e(route('profile.cancel-order', $order->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <div class="modal-body">
                                    <p>Are you sure you want to cancel this order? This cannot be undone.</p>
                                    <div class="form-group">
                                        <label for="reason">Reason <small class="text-muted">(optional)</small></label>
                                        <select class="form-control" id="reason" name="reason">
                                            <option value="">-- Select a reason --</option>
                                            <option>Changed my mind</option>
                                            <option>Ordered by mistake</option>
                                            <option>Found a better price elsewhere</option>
                                            <option>Delivery time is too long</option>
                                            <option>Other</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Keep Order</button>
                                    <button type="submit" class="btn btn-danger">Yes, Cancel Order</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.eshopper', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/prakash/urbandenim/resources/views/front/profile/order-details.blade.php ENDPATH**/ ?>