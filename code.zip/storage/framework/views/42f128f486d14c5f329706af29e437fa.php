<?php $__env->startSection('content'); ?>
    <!-- Page Header Start -->
    <div class="container-fluid bg-secondary mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px">
            <h1 class="font-weight-semi-bold text-uppercase mb-3">My Account</h1>
            <div class="d-inline-flex">
                <p class="m-0"><a href="<?php echo e(url('/')); ?>">Home</a></p>
                <p class="m-0 px-2">-</p>
                <p class="m-0">My Account</p>
            </div>
        </div>
    </div>
    <!-- Page Header End -->

    <div class="container-fluid pt-5 pb-5">
        <div class="row px-xl-5">
            <!-- Sidebar -->
            <?php echo $__env->make('front.partials.profile-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <!-- Main Content -->
            <div class="col-lg-9 mb-5">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                    </div>
                <?php endif; ?>

                <!-- Stats -->
                <div class="row mb-5">
                    <div class="col-md-4 mb-3">
                        <div class="border text-center p-4">
                            <i class="fa fa-shopping-bag fa-2x text-primary mb-3"></i>
                            <h4 class="font-weight-bold"><?php echo e($orderCount); ?></h4>
                            <p class="m-0">Total Orders</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="border text-center p-4">
                            <i class="fa fa-heart fa-2x text-primary mb-3"></i>
                            <h4 class="font-weight-bold"><?php echo e($wishlistCount); ?></h4>
                            <p class="m-0">Wishlist Items</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="border text-center p-4">
                            <i class="fa fa-map-marker-alt fa-2x text-primary mb-3"></i>
                            <h4 class="font-weight-bold"><?php echo e($user->addresses()->count()); ?></h4>
                            <p class="m-0">Saved Addresses</p>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="bg-light p-4">
                    <h5 class="font-weight-semi-bold mb-4">Quick Actions</h5>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <a href="<?php echo e(route('profile.personal-info')); ?>" class="d-flex align-items-center border bg-white p-3 text-dark text-decoration-none">
                                <i class="fa fa-user text-primary fa-lg mr-3"></i>
                                <div>
                                    <h6 class="mb-0">Edit Profile</h6>
                                    <small class="text-muted">Update your personal information</small>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6 mb-3">
                            <a href="<?php echo e(route('profile.orders')); ?>" class="d-flex align-items-center border bg-white p-3 text-dark text-decoration-none">
                                <i class="fa fa-shopping-bag text-primary fa-lg mr-3"></i>
                                <div>
                                    <h6 class="mb-0">View Orders</h6>
                                    <small class="text-muted">Track and manage your orders</small>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6 mb-3">
                            <a href="<?php echo e(route('profile.addresses')); ?>" class="d-flex align-items-center border bg-white p-3 text-dark text-decoration-none">
                                <i class="fa fa-map-marker-alt text-primary fa-lg mr-3"></i>
                                <div>
                                    <h6 class="mb-0">Manage Addresses</h6>
                                    <small class="text-muted">Add or edit delivery addresses</small>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6 mb-3">
                            <a href="<?php echo e(route('wishlist.index')); ?>" class="d-flex align-items-center border bg-white p-3 text-dark text-decoration-none">
                                <i class="fa fa-heart text-primary fa-lg mr-3"></i>
                                <div>
                                    <h6 class="mb-0">My Wishlist</h6>
                                    <small class="text-muted">Products you've saved</small>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.eshopper', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/prakash/urbandenim/resources/views/front/profile/dashboard.blade.php ENDPATH**/ ?>