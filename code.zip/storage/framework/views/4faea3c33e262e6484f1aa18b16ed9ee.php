<?php $__env->startSection('content'); ?>
    <div class="container-fluid bg-secondary mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px">
            <h1 class="font-weight-semi-bold text-uppercase mb-3">My Addresses</h1>
            <div class="d-inline-flex">
                <p class="m-0"><a href="<?php echo e(url('/')); ?>">Home</a></p>
                <p class="m-0 px-2">-</p>
                <p class="m-0"><a href="<?php echo e(route('profile.dashboard')); ?>">My Account</a></p>
                <p class="m-0 px-2">-</p>
                <p class="m-0">Addresses</p>
            </div>
        </div>
    </div>

    <div class="container-fluid pt-5 pb-5">
        <div class="row px-xl-5">
            <?php echo $__env->make('front.partials.profile-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="col-lg-9 mb-5">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                    </div>
                <?php endif; ?>

                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h5 class="font-weight-semi-bold m-0">Saved Addresses</h5>
                    <a href="<?php echo e(route('profile.address.create')); ?>" class="btn btn-primary"><i class="fa fa-plus mr-2"></i>Add New Address</a>
                </div>

                <?php if($addresses->isEmpty()): ?>
                    <div class="text-center py-5 bg-light">
                        <i class="fa fa-map-marker-alt fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No addresses saved yet</h5>
                        <a href="<?php echo e(route('profile.address.create')); ?>" class="btn btn-primary mt-3">Add Your First Address</a>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 mb-4">
                                <div class="border p-4 h-100 position-relative">
                                    <?php if($address->is_default): ?>
                                        <span class="badge badge-primary position-absolute" style="top:10px;right:10px;">Default</span>
                                    <?php endif; ?>
                                    <div class="d-flex align-items-center mb-2">
                                        <i class="fa fa-<?php echo e($address->address_type === 'billing' ? 'file-invoice' : 'truck'); ?> text-primary mr-2"></i>
                                        <strong class="text-capitalize"><?php echo e($address->address_type); ?> Address</strong>
                                    </div>
                                    <p class="mb-1"><?php echo e($address->full_name); ?></p>
                                    <p class="mb-1 text-muted"><?php echo e($address->street); ?></p>
                                    <p class="mb-1 text-muted"><?php echo e($address->city); ?>, <?php echo e($address->state); ?> <?php echo e($address->postal_code); ?></p>
                                    <p class="mb-3 text-muted"><?php echo e($address->country); ?></p>
                                    <p class="mb-3 text-muted"><i class="fa fa-phone mr-1"></i><?php echo e($address->phone); ?></p>
                                    <div class="d-flex">
                                        <a href="<?php echo e(route('profile.address.edit', $address->id)); ?>" class="btn btn-sm btn-outline-primary mr-2">Edit</a>
                                        <form method="POST" action="<?php echo e(route('profile.address.delete', $address->id)); ?>" onsubmit="return confirm('Delete this address?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.eshopper', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/prakash/urbandenim/resources/views/front/profile/addresses.blade.php ENDPATH**/ ?>