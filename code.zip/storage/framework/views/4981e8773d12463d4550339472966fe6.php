<?php $__env->startSection('title', 'My Wishlist - EShopper'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('front.partials.page-banner', ['title' => 'My Wishlist', 'breadcrumb' => 'Wishlist'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Wishlist Start -->
    <div class="container-fluid pt-5">
        <div class="row px-xl-5">

            <?php if(session('success')): ?>
            <div class="col-12">
                <div class="alert alert-success alert-dismissible fade show">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
            </div>
            <?php endif; ?>

            <?php if($wishlistItems->isEmpty()): ?>
            <div class="col-12 text-center py-5">
                <i class="far fa-heart fa-4x text-muted mb-4"></i>
                <h4 class="text-muted">Your wishlist is empty</h4>
                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary mt-3 px-5">Browse Products</a>
            </div>
            <?php else: ?>
            <?php $__currentLoopData = $wishlistItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $product = $item->product; ?>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="card product-item border-0 mb-4">
                    <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                        <?php if($product && $product->images && $product->images->isNotEmpty()): ?>
                            <img class="img-fluid w-100" src="<?php echo e($product->images->first()->url); ?>" alt="<?php echo e($product->name); ?>">
                        <?php else: ?>
                            <img class="img-fluid w-100" src="<?php echo e(asset('eshopper/img/product-1.jpg')); ?>" alt="">
                        <?php endif; ?>
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                        <h6 class="text-truncate mb-3"><?php echo e($product->name ?? 'Product'); ?></h6>
                        <div class="d-flex justify-content-center">
                            <h6>₹<?php echo e(number_format($product->sale_price ?? $product->price ?? 0, 2)); ?></h6>
                            <?php if($product && $product->sale_price && $product->sale_price < $product->price): ?>
                                <h6 class="text-muted ml-2"><del>₹<?php echo e(number_format($product->price, 2)); ?></del></h6>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-footer bg-light border p-0">
                        <div class="d-flex">
                            <form method="POST" action="<?php echo e(route('wishlist.move-to-cart')); ?>" class="flex-grow-1">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                <button type="submit" class="btn btn-sm text-dark w-100 border-right p-2">
                                    <i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart
                                </button>
                            </form>
                            <form method="POST" action="<?php echo e(route('wishlist.remove')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                <button type="submit" class="btn btn-sm text-dark p-2">
                                    <i class="fas fa-times text-danger"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if($wishlistItems->hasPages()): ?>
            <div class="col-12 mt-2">
                <nav>
                    <ul class="pagination justify-content-center">
                        <li class="page-item <?php echo e($wishlistItems->onFirstPage() ? 'disabled' : ''); ?>">
                            <a class="page-link" href="<?php echo e($wishlistItems->previousPageUrl()); ?>">Previous</a>
                        </li>
                        <?php $__currentLoopData = $wishlistItems->getUrlRange(1, $wishlistItems->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="page-item <?php echo e($wishlistItems->currentPage() == $page ? 'active' : ''); ?>">
                            <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li class="page-item <?php echo e($wishlistItems->hasMorePages() ? '' : 'disabled'); ?>">
                            <a class="page-link" href="<?php echo e($wishlistItems->nextPageUrl()); ?>">Next</a>
                        </li>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
            <?php endif; ?>

        </div>
    </div>
    <!-- Wishlist End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.eshopper', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/prakash/urbandenim/resources/views/front/wishlist.blade.php ENDPATH**/ ?>