<?php $__env->startSection('title', 'Categories Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-title d-flex justify-content-between align-items-center">
    <h2><i class="fas fa-th"></i> Categories Management</h2>
    <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus"></i> Add New Category
    </a>
</div>

<!-- Search & Filter -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-6">
                <input type="text" name="search" class="form-control" placeholder="Search categories...">
            </div>
            <div class="col-md-6">
                <button type="submit" class="btn btn-outline-secondary">
                    <i class="fas fa-search"></i> Search
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Categories Table -->
<div class="card">
    <div class="card-header">
        <span>All Categories (<?php echo e($categories->total()); ?>)</span>
    </div>
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Slug</th>
                    <th>Parent</th>
                    <th>Subcategories</th>
                    <th>Products</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><strong>#<?php echo e($category->id); ?></strong></td>
                        <td>
                            <img src="<?php echo e($category->image); ?>" alt="<?php echo e($category->name); ?>"
                                 style="height:40px; width:40px; object-fit:cover; border-radius:4px;">
                        </td>
                        <td><?php echo e($category->name); ?></td>
                        <td><code><?php echo e($category->slug); ?></code></td>
                        <td>
                            <?php if($category->parent_id): ?>
                                <span class="badge bg-info"><?php echo e($category->parent->name); ?></span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Main</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($category->children->count() > 0): ?>
                                <span class="badge bg-success"><?php echo e($category->children->count()); ?></span>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php $productCount = $category->products()->count(); ?>
                            <span class="badge bg-primary"><?php echo e($productCount); ?></span>
                        </td>
                        <td>
                            <?php if($category->is_active): ?>
                                <span class="badge bg-success">Active</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('admin.categories.edit', $category)); ?>" class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <form action="<?php echo e(route('admin.categories.destroy', $category)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">
                                        <i class="fas fa-trash"></i> Delete
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>

                    <!-- Show Subcategories -->
                    <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="background-color: #f5f5f5;">
                            <td><strong>#<?php echo e($subcategory->id); ?></strong></td>
                            <td>
                                <img src="<?php echo e($subcategory->image); ?>" alt="<?php echo e($subcategory->name); ?>"
                                     style="height:40px; width:40px; object-fit:cover; border-radius:4px;">
                            </td>
                            <td style="padding-left: 40px;">
                                <i class="fas fa-arrow-right text-muted"></i> <?php echo e($subcategory->name); ?>

                            </td>
                            <td><code><?php echo e($subcategory->slug); ?></code></td>
                            <td><span class="badge bg-info"><?php echo e($category->name); ?></span></td>
                            <td><span class="text-muted">-</span></td>
                            <td>
                                <?php $subProductCount = $subcategory->products()->count(); ?>
                                <span class="badge bg-primary"><?php echo e($subProductCount); ?></span>
                            </td>
                            <td>
                                <?php if($subcategory->is_active): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="<?php echo e(route('admin.categories.edit', $subcategory)); ?>" class="btn btn-sm btn-warning">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <form action="<?php echo e(route('admin.categories.destroy', $subcategory)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" class="text-center text-muted py-4">
                            <i class="fas fa-inbox"></i> No categories found
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Pagination -->
<div class="d-flex justify-content-center mt-4">
    <?php echo e($categories->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/prakash/urbandenim/resources/views/admin/categories/index.blade.php ENDPATH**/ ?>