<?php echo $__env->make('front.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('front.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH /home/prakash/urbandenim/resources/views/layouts/eshopper.blade.php ENDPATH**/ ?>