<?php $__env->startSection('title', 'Banners Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-title d-flex justify-content-between align-items-center">
    <h2><i class="fas fa-bullhorn"></i> Banners Management</h2>
    <a href="<?php echo e(route('admin.banners.create', ['type' => $type ?: null])); ?>" class="btn btn-primary">
        <i class="fas fa-plus"></i> Add Banner
    </a>
</div>

<div class="card mt-3">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span>
            All Banners
            <?php if($type): ?>
                <span class="text-muted">(Type: <?php echo e(ucfirst($type)); ?>)</span>
            <?php endif; ?>
            (<?php echo e($banners->total()); ?>)
        </span>

        <form method="GET" class="d-flex gap-2 align-items-center">
            <select name="type" class="form-select form-select-sm" style="width: 220px;">
                <option value="" <?php if(!$type): echo 'selected'; endif; ?>>All Types</option>
                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($t); ?>" <?php if($type === $t): echo 'selected'; endif; ?>><?php echo e(ucfirst($t)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button class="btn btn-sm btn-secondary" type="submit">
                <i class="fas fa-filter"></i> Filter
            </button>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Type</th>
                    <th>Title</th>
                    <th>Image</th>
                    <th>Link</th>
                    <th>Sort</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><strong>#<?php echo e($banner->id); ?></strong></td>
                        <td><code><?php echo e($banner->type); ?></code></td>
                        <td><?php echo e($banner->title ?? '-'); ?></td>
                        <td>
                            <img src="<?php echo e($banner->image); ?>" alt="<?php echo e($banner->title ?? 'banner'); ?>" style="height:50px; width:auto; object-fit:contain;" />
                        </td>
                        <td>
                            <?php if($banner->link_url): ?>
                                <a href="<?php echo e($banner->link_url); ?>" target="_blank" rel="noopener">Open</a>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($banner->sort_order); ?></td>
                        <td>
                            <?php if($banner->is_active): ?>
                                <span class="badge bg-success">Active</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('admin.banners.edit', $banner)); ?>" class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <form action="<?php echo e(route('admin.banners.destroy', $banner)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">
                                        <i class="fas fa-trash"></i> Delete
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted py-4">
                            <i class="fas fa-inbox"></i> No banners found
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="d-flex justify-content-center mt-4">
    <?php echo e($banners->links()); ?>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/prakash/urbandenim/resources/views/admin/banners/index.blade.php ENDPATH**/ ?>