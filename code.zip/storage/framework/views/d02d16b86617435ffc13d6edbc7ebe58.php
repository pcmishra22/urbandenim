<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><style>
body{font-family:Arial,sans-serif;background:#f5f5f5;margin:0;padding:0;}
.wrap{max-width:600px;margin:30px auto;background:#fff;border-radius:8px;overflow:hidden;}
.header{background:#1e2a3a;padding:24px 32px;}
.header h1{color:#fff;margin:0;font-size:20px;}
.body{padding:28px;}
.info-box{background:#f8f9fa;border-radius:6px;padding:14px 16px;margin:12px 0;}
.info-box p{margin:4px 0;font-size:14px;}
table{width:100%;border-collapse:collapse;font-size:14px;margin:12px 0;}
th{background:#1e2a3a;color:#fff;padding:8px 10px;text-align:left;}
td{padding:7px 10px;border-bottom:1px solid #eee;}
.btn{display:inline-block;padding:10px 24px;background:#1e2a3a;color:#fff;text-decoration:none;border-radius:4px;font-weight:bold;}
.footer{background:#f5f5f5;padding:14px 32px;text-align:center;font-size:12px;color:#888;}
</style></head>
<body>
<div class="wrap">
    <div class="header"><h1>🛒 New Order #<?php echo e($order->id); ?> — ₹<?php echo e(number_format($order->total_price,2)); ?></h1></div>
    <div class="body">
        <div class="info-box">
            <p><strong>Customer:</strong> <?php echo e($order->user->name); ?> (<?php echo e($order->user->email); ?>)</p>
            <p><strong>Order Date:</strong> <?php echo e($order->created_at->format('d M Y, h:i A')); ?></p>
            <p><strong>Payment:</strong>
                <?php if($order->payment_method==='cod'): ?> Cash on Delivery
                <?php elseif($order->payment_method==='upi'): ?> UPI / Net Banking
                <?php else: ?> Card <?php endif; ?> — <strong><?php echo e(ucfirst($order->payment_status ?? 'pending')); ?></strong>
            </p>
            <p><strong>Ship To:</strong> <?php echo e($order->shipping_full_name); ?>, <?php echo e($order->shipping_city); ?>, <?php echo e($order->shipping_state); ?></p>
        </div>
        <table>
            <thead><tr><th>Product</th><th>Qty</th><th>Price</th></tr></thead>
            <tbody>
                <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr><td><?php echo e($p->name); ?></td><td><?php echo e($p->pivot->quantity); ?></td><td>₹<?php echo e(number_format($p->pivot->price,2)); ?></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr><td colspan="2" style="text-align:right;font-weight:bold">Total</td>
                    <td style="font-weight:bold">₹<?php echo e(number_format($order->total_price,2)); ?></td></tr>
            </tbody>
        </table>
        <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>" class="btn">View Order in Admin</a>
    </div>
    <div class="footer">EShopper Admin Notification</div>
</div>
</body></html>
<?php /**PATH /home/prakash/urbandenim/resources/views/emails/admin/new-order.blade.php ENDPATH**/ ?>