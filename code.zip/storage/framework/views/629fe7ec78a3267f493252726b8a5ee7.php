<?php $__env->startSection('title', $product->name . ' - EShopper'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Page Header Start -->
    <div class="container-fluid bg-secondary mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px">
            <h1 class="font-weight-semi-bold text-uppercase mb-3">Shop Detail</h1>
            <div class="d-inline-flex">
                <p class="m-0"><a href="<?php echo e(url('/')); ?>">Home</a></p>
                <p class="m-0 px-2">-</p>
                <p class="m-0"><a href="<?php echo e(route('products.index')); ?>">Shop</a></p>
                <p class="m-0 px-2">-</p>
                <p class="m-0"><?php echo e($product->name); ?></p>
            </div>
        </div>
    </div>
    <!-- Page Header End -->

    <!-- Shop Detail Start -->
    <div class="container-fluid py-5">
        <div class="row px-xl-5">

            <!-- Product Images -->
            <div class="col-lg-5 pb-5">
                <div id="product-carousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner border">
<?php if($product->images && $product->images->isNotEmpty()): ?>
                            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $filename = $image->image ?? '';
                                    $relativePath = 'products/' . $product->id . '/images/' . $filename;
                                    $publicUrl = asset('storage/' . $relativePath);
                                    $fallbackUrl = asset('storage/default.jpeg');
                                ?>
                                <div class="carousel-item <?php echo e($i === 0 ? 'active' : ''); ?>">
                                    <img class="w-100" style="height:400px;object-fit:contain;" src="<?php echo e(file_exists(public_path('storage/' . $relativePath)) ? $publicUrl : $fallbackUrl); ?>" alt="<?php echo e($product->name); ?>">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="carousel-item active">
                                <img class="w-100" style="height:400px;object-fit:contain;" src="<?php echo e(asset('storage/default.jpeg')); ?>" alt="<?php echo e($product->name); ?>">
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php if($product->images && $product->images->count() > 1): ?>
                    <a class="carousel-control-prev" href="#product-carousel" data-slide="prev">
                        <i class="fa fa-2x fa-angle-left text-dark"></i>
                    </a>
                    <a class="carousel-control-next" href="#product-carousel" data-slide="next">
                        <i class="fa fa-2x fa-angle-right text-dark"></i>
                    </a>
                    <?php endif; ?>
                </div>
                <!-- Thumbnails -->
                <?php if($product->images && $product->images->count() > 1): ?>
                <div class="d-flex mt-3">
                    <?php $__currentLoopData = $product->images->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $filename = $image->image ?? '';
                            $relativePath = 'products/' . $product->id . '/images/' . $filename;
                            $publicUrl = asset('storage/' . $relativePath);
                            $fallbackUrl = asset('storage/default.jpeg');
                        ?>
                        <a href="#product-carousel" data-target="#product-carousel" data-slide-to="<?php echo e($i); ?>" class="mr-2">
                            <img class="border" style="width:60px;height:60px;object-fit:cover;" src="<?php echo e(file_exists(public_path('storage/' . $relativePath)) ? $publicUrl : $fallbackUrl); ?>" alt="">
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Product Info -->
            <div class="col-lg-7 pb-5">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                    </div>
                <?php endif; ?>

                <h3 class="font-weight-semi-bold"><?php echo e($product->name); ?></h3>

                <!-- Rating -->
                <?php $avgRating = $product->reviews ? $product->reviews->avg('rating') : 0; $reviewCount = $product->reviews ? $product->reviews->count() : 0; ?>
                <div class="d-flex mb-3">
                    <div class="text-primary mr-2">
                        <?php for($s = 1; $s <= 5; $s++): ?>
                            <?php if($s <= floor($avgRating)): ?>
                                <small class="fas fa-star"></small>
                            <?php elseif($s - 0.5 <= $avgRating): ?>
                                <small class="fas fa-star-half-alt"></small>
                            <?php else: ?>
                                <small class="far fa-star"></small>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </div>
                    <small class="pt-1">(<?php echo e($reviewCount); ?> Reviews)</small>
                </div>

                <!-- Price -->
                <div class="d-flex mb-3">
                    <h3 class="font-weight-semi-bold mb-0">₹<?php echo e(number_format($product->sale_price ?? $product->price, 2)); ?></h3>
                    <?php if($product->sale_price && $product->sale_price < $product->price): ?>
                        <h5 class="text-muted ml-3 mt-1"><del>₹<?php echo e(number_format($product->price, 2)); ?></del></h5>
                        <span class="badge badge-primary ml-2 align-self-center">
                            -<?php echo e(round((1 - $product->sale_price / $product->price) * 100)); ?>%
                        </span>
                    <?php endif; ?>
                </div>

                <p class="mb-4"><?php echo e($product->description); ?></p>

                <!-- Category & Brand -->
                <div class="mb-2">
                    <?php if($product->category): ?>
                        <span class="text-dark font-weight-medium">Category:</span>
                        <a href="<?php echo e(route('products.index', ['category' => $product->category_id])); ?>" class="ml-1"><?php echo e($product->category->name); ?></a>
                    <?php endif; ?>
                </div>
                <?php if($product->brand): ?>
                <div class="mb-4">
                    <span class="text-dark font-weight-medium">Brand:</span>
                    <span class="ml-1"><?php echo e($product->brand->name); ?></span>
                </div>
                <?php endif; ?>

                <!-- Variants -->
                <?php
                    $sizes = $product->variants ? $product->variants->pluck('size')->filter()->unique()->values() : collect();
                    $colors = $product->variants ? $product->variants->pluck('color')->filter()->unique()->values() : collect();
                ?>

                <?php if($sizes->isNotEmpty()): ?>
                <div class="d-flex mb-3">
                    <p class="text-dark font-weight-medium mb-0 mr-3">Sizes:</p>
                    <div>
                        <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input size-radio" id="size-<?php echo e($size); ?>" name="selected_size" value="<?php echo e($size); ?>">
                            <label class="custom-control-label" for="size-<?php echo e($size); ?>"><?php echo e($size); ?></label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>

                <?php if($colors->isNotEmpty()): ?>
                <div class="d-flex mb-4">
                    <p class="text-dark font-weight-medium mb-0 mr-3">Colors:</p>
                    <div>
                        <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" id="color-<?php echo e($color); ?>" name="selected_color" value="<?php echo e($color); ?>">
                            <label class="custom-control-label" for="color-<?php echo e($color); ?>"><?php echo e($color); ?></label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Add to Cart -->
                <form method="POST" action="<?php echo e(route('cart.add')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                    <div class="d-flex align-items-center mb-4 pt-2">
                        <div class="input-group quantity mr-3" style="width: 130px;">
                            <div class="input-group-btn">
                                <button type="button" class="btn btn-primary btn-minus"><i class="fa fa-minus"></i></button>
                            </div>
                            <input type="text" name="quantity" class="form-control bg-secondary text-center" value="1" min="1">
                            <div class="input-group-btn">
                                <button type="button" class="btn btn-primary btn-plus"><i class="fa fa-plus"></i></button>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary px-3">
                            <i class="fa fa-shopping-cart mr-1"></i> Add To Cart
                        </button>
                        <?php if(auth()->guard()->check()): ?>
                        <form method="POST" action="<?php echo e(route('wishlist.add')); ?>" class="ml-3">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                            <button type="submit" class="btn btn-outline-secondary px-3">
                                <i class="far fa-heart mr-1"></i> Wishlist
                            </button>
                        </form>
                        <?php endif; ?>
                    </div>
                </form>

                <!-- Share -->
                <div class="d-flex pt-2">
                    <p class="text-dark font-weight-medium mb-0 mr-2">Share on:</p>
                    <div class="d-inline-flex">
                        <a class="text-dark px-2" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(request()->fullUrl())); ?>" target="_blank"><i class="fab fa-facebook-f"></i></a>
                        <a class="text-dark px-2" href="https://twitter.com/intent/tweet?url=<?php echo e(urlencode(request()->fullUrl())); ?>&text=<?php echo e(urlencode($product->name)); ?>" target="_blank"><i class="fab fa-twitter"></i></a>
                        <a class="text-dark px-2" href="https://www.pinterest.com/pin/create/button/?url=<?php echo e(urlencode(request()->fullUrl())); ?>" target="_blank"><i class="fab fa-pinterest"></i></a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tabs: Description / Info / Reviews -->
        <div class="row px-xl-5">
            <div class="col">
                <div class="nav nav-tabs justify-content-center border-secondary mb-4">
                    <a class="nav-item nav-link active" data-toggle="tab" href="#tab-description">Description</a>
                    <a class="nav-item nav-link" data-toggle="tab" href="#tab-info">Information</a>
                    <a class="nav-item nav-link" data-toggle="tab" href="#tab-reviews">
                        Reviews (<?php echo e($reviewCount); ?>)
                    </a>
                </div>
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="tab-description">
                        <h4 class="mb-3">Product Description</h4>
                        <p><?php echo e($product->description ?? 'No description available.'); ?></p>
                    </div>
                    <div class="tab-pane fade" id="tab-info">
                        <h4 class="mb-3">Additional Information</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <ul class="list-group list-group-flush">
                                    <?php if($product->sku): ?><li class="list-group-item px-0">SKU: <?php echo e($product->sku); ?></li><?php endif; ?>
                                    <?php if($product->category): ?><li class="list-group-item px-0">Category: <?php echo e($product->category->name); ?></li><?php endif; ?>
                                    <?php if($product->brand): ?><li class="list-group-item px-0">Brand: <?php echo e($product->brand->name); ?></li><?php endif; ?>
                                    <?php if($product->gender): ?><li class="list-group-item px-0">Gender: <?php echo e(ucfirst($product->gender)); ?></li><?php endif; ?>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <ul class="list-group list-group-flush">
                                    <?php if($product->color_family): ?><li class="list-group-item px-0">Colour: <?php echo e($product->color_family); ?></li><?php endif; ?>
                                    <?php if($product->age_group): ?><li class="list-group-item px-0">Age Group: <?php echo e($product->age_group); ?></li><?php endif; ?>
                                    <li class="list-group-item px-0">Availability: <?php echo e($product->quantity > 0 ? 'In Stock (' . $product->quantity . ')' : 'Out of Stock'); ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="tab-reviews">
                        <div class="row">
                            <div class="col-md-6">
                                <h4 class="mb-4"><?php echo e($reviewCount); ?> review<?php echo e($reviewCount != 1 ? 's' : ''); ?> for "<?php echo e($product->name); ?>"</h4>
                                <?php if($product->reviews && $product->reviews->isNotEmpty()): ?>
                                    <?php $__currentLoopData = $product->reviews->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="media mb-4">
                                        <div class="rounded-circle bg-primary d-flex align-items-center justify-content-center mr-3" style="width:45px;height:45px;min-width:45px;">
                                            <i class="fa fa-user text-white"></i>
                                        </div>
                                        <div class="media-body">
                                            <h6><?php echo e($review->user->name ?? 'Anonymous'); ?><small> - <i><?php echo e($review->created_at->format('d M Y')); ?></i></small></h6>
                                            <div class="text-primary mb-2">
                                                <?php for($s = 1; $s <= 5; $s++): ?>
                                                    <i class="<?php echo e($s <= $review->rating ? 'fas' : 'far'); ?> fa-star"></i>
                                                <?php endfor; ?>
                                            </div>
                                            <p><?php echo e($review->review_text); ?></p>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <p class="text-muted">No reviews yet. Be the first to review!</p>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <h4 class="mb-4">Leave a review</h4>
                                <?php if(auth()->guard()->check()): ?>
                                <form method="POST" action="<?php echo e(route('products.review', $product->id) ?? '#'); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="d-flex my-3">
                                        <p class="mb-0 mr-2">Your Rating * :</p>
                                        <div class="text-primary" id="star-rating">
                                            <?php for($s = 1; $s <= 5; $s++): ?>
                                            <i class="far fa-star star-btn" data-val="<?php echo e($s); ?>" style="cursor:pointer;font-size:1.2rem;"></i>
                                            <?php endfor; ?>
                                        </div>
                                        <input type="hidden" name="rating" id="rating-val" value="0">
                                    </div>
                                    <div class="form-group">
                                        <label>Your Review *</label>
                                        <textarea name="review_text" rows="5" class="form-control" required></textarea>
                                    </div>
                                    <div class="form-group mb-0">
                                        <button type="submit" class="btn btn-primary px-3">Leave Your Review</button>
                                    </div>
                                </form>
                                <?php else: ?>
                                <div class="alert alert-info">
                                    <a href="<?php echo e(route('customer.login')); ?>">Login</a> to leave a review.
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Related Products -->
        <?php if($relatedProducts->isNotEmpty()): ?>
        <div class="row px-xl-5 mt-5">
            <div class="col-12 text-center mb-4">
                <h2 class="section-title px-5"><span class="px-2">Related Products</span></h2>
            </div>
            <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('front.partials.product-card', ['product' => $related], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>
    <!-- Shop Detail End -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// Quantity +/-
$(document).on('click', '.btn-plus', function() {
    var $input = $(this).closest('.quantity').find('input');
    var val = parseInt($input.val()) || 1;
    $input.val(val + 1);
});
$(document).on('click', '.btn-minus', function() {
    var $input = $(this).closest('.quantity').find('input');
    var val = parseInt($input.val()) || 1;
    if (val > 1) $input.val(val - 1);
});
// Star rating
$('.star-btn').on('click', function() {
    var val = $(this).data('val');
    $('#rating-val').val(val);
    $('.star-btn').each(function() {
        $(this).toggleClass('fas', $(this).data('val') <= val)
               .toggleClass('far', $(this).data('val') > val);
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.eshopper', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/prakash/urbandenim/resources/views/front/product-detail.blade.php ENDPATH**/ ?>