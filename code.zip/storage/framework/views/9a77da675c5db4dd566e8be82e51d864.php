<?php $__env->startSection('title', 'Orders - Admin Listing'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-title d-flex justify-content-between align-items-center">
    <h2><i class="fas fa-receipt"></i> Orders</h2>
</div>

<div class="card">
    <div class="card-header">
        <span>All Orders</span>
    </div>

    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>Order #</th>
                    <th>Customer</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><strong>#<?php echo e($order->id); ?></strong></td>
                        <td><?php echo e($order->user->name ?? '-'); ?></td>
                        <td><?php echo e($order->total_price); ?></td>
                        <td>
                            <?php $s = $order->status; ?>
                            <?php if($s === 'pending'): ?>
                                <span class="badge badge-pending">Pending</span>
                            <?php elseif($s === 'confirmed'): ?>
                                <span class="badge badge-processing">Confirmed</span>
                            <?php elseif($s === 'packed'): ?>
                                <span class="badge badge-processing">Packed</span>
                            <?php elseif($s === 'shipped'): ?>
                                <span class="badge badge-shipped">Shipped</span>
                            <?php elseif($s === 'delivered'): ?>
                                <span class="badge badge-delivered">Delivered</span>
                            <?php elseif($s === 'cancelled'): ?>
                                <span class="badge badge-cancelled">Cancelled</span>
                            <?php else: ?>
                                <span class="badge bg-secondary"><?php echo e($s); ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($order->created_at ? $order->created_at->format('Y-m-d H:i') : '-'); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-eye"></i> View
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">No orders found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="d-flex justify-content-center mt-4">
        <?php echo e($orders->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/prakash/urbandenim/resources/views/admin/orders/index.blade.php ENDPATH**/ ?>