<?php $__env->startSection('title', 'My Dashboard - EShopper'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('front.partials.page-banner', ['title' => 'My Account', 'breadcrumb' => 'Dashboard'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="container-fluid pt-5 pb-5">
        <div class="row px-xl-5">
            <?php echo $__env->make('front.partials.profile-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="col-lg-9 mb-5">
                <h5 class="font-weight-semi-bold mb-4">Welcome, <?php echo e(Auth::user()->name); ?>!</h5>
                <div class="row mb-4">
                    <div class="col-md-4 mb-3">
                        <div class="border rounded p-4 text-center">
                            <i class="fa fa-shopping-bag fa-2x text-primary mb-2"></i>
                            <h3 class="font-weight-bold"><?php echo e($orders->total()); ?></h3>
                            <p class="text-muted mb-0">Total Orders</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="border rounded p-4 text-center">
                            <i class="fa fa-clock fa-2x text-warning mb-2"></i>
                            <h3 class="font-weight-bold"><?php echo e(\App\Models\Order::where('user_id',Auth::id())->whereIn('status',['pending','processing'])->count()); ?></h3>
                            <p class="text-muted mb-0">Active Orders</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="border rounded p-4 text-center">
                            <i class="fa fa-rupee-sign fa-2x text-success mb-2"></i>
                            <h3 class="font-weight-bold">₹<?php echo e(number_format(\App\Models\Order::where('user_id',Auth::id())->whereNotIn('status',['cancelled'])->sum('total_price'),0)); ?></h3>
                            <p class="text-muted mb-0">Total Spent</p>
                        </div>
                    </div>
                </div>
                <h6 class="font-weight-semi-bold mb-3">Recent Orders</h6>
                <?php if($orders->isEmpty()): ?>
                    <div class="text-center py-5 bg-light rounded">
                        <i class="fa fa-shopping-bag fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No orders yet</h5>
                        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary mt-2">Start Shopping</a>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-bordered text-center">
                            <thead class="bg-secondary"><tr><th>Order #</th><th>Date</th><th>Total</th><th>Status</th><th>Action</th></tr></thead>
                            <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $bm=['pending'=>'warning','processing'=>'info','shipped'=>'primary','delivered'=>'success','cancelled'=>'danger']; ?>
                                <tr>
                                    <td><strong>#<?php echo e($order->id); ?></strong></td>
                                    <td><?php echo e($order->created_at->format('d M Y')); ?></td>
                                    <td>₹<?php echo e(number_format($order->total_price,2)); ?></td>
                                    <td><span class="badge badge-<?php echo e($bm[$order->status]??'secondary'); ?> text-capitalize"><?php echo e($order->status); ?></span></td>
                                    <td><a href="<?php echo e(route('profile.order-details',$order->id)); ?>" class="btn btn-sm btn-outline-primary">View</a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-3"><?php echo e($orders->links()); ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.eshopper', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/prakash/urbandenim/resources/views/dashboard/customer.blade.php ENDPATH**/ ?>