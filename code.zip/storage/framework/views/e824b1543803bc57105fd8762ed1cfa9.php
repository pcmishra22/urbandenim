<?php $__env->startSection('title', 'Order Confirmed - EShopper'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Page Header -->
    <div class="container-fluid bg-secondary mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px">
            <h1 class="font-weight-semi-bold text-uppercase mb-3">Order Confirmed</h1>
            <div class="d-inline-flex">
                <p class="m-0"><a href="<?php echo e(url('/')); ?>">Home</a></p>
                <p class="m-0 px-2">-</p>
                <p class="m-0">Order Confirmation</p>
            </div>
        </div>
    </div>

    <div class="container-fluid pt-3 pb-5">
        <div class="row px-xl-5 justify-content-center">
            <div class="col-lg-8">

                <!-- Success Banner -->
                <div class="text-center py-5 mb-4 border rounded" style="background:#f8fff8;">
                    <div class="mb-3" style="font-size:64px; color:#28a745;">
                        <i class="fa fa-check-circle"></i>
                    </div>
                    <h3 class="font-weight-bold mb-2">Thank you for your order!</h3>
                    <p class="text-muted mb-1">
                        Your order <strong>#<?php echo e($order->id); ?></strong> has been placed successfully.
                    </p>
                    <p class="text-muted mb-0">
                        <?php if($order->payment_method === 'cod'): ?>
                            You'll pay <strong>₹<?php echo e(number_format($order->total_price, 2)); ?></strong> on delivery.
                        <?php else: ?>
                            Payment of <strong>₹<?php echo e(number_format($order->total_price, 2)); ?></strong> received.
                        <?php endif; ?>
                    </p>
                </div>

                <!-- Order Info Row -->
                <div class="row mb-4 text-center">
                    <div class="col-6 col-md-3 mb-3">
                        <div class="border rounded p-3 h-100">
                            <small class="text-muted d-block mb-1">Order Number</small>
                            <strong>#<?php echo e($order->id); ?></strong>
                        </div>
                    </div>
                    <div class="col-6 col-md-3 mb-3">
                        <div class="border rounded p-3 h-100">
                            <small class="text-muted d-block mb-1">Order Date</small>
                            <strong><?php echo e($order->created_at->format('d M Y')); ?></strong>
                        </div>
                    </div>
                    <div class="col-6 col-md-3 mb-3">
                        <div class="border rounded p-3 h-100">
                            <small class="text-muted d-block mb-1">Payment</small>
                            <strong class="text-capitalize">
                                <?php if($order->payment_method === 'cod'): ?> Cash on Delivery
                                <?php elseif($order->payment_method === 'upi'): ?> UPI / Net Banking
                                <?php else: ?> Credit / Debit Card
                                <?php endif; ?>
                            </strong>
                        </div>
                    </div>
                    <div class="col-6 col-md-3 mb-3">
                        <div class="border rounded p-3 h-100">
                            <small class="text-muted d-block mb-1">Status</small>
                            <span class="badge badge-warning text-capitalize"><?php echo e($order->status); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Items Ordered -->
                <div class="card border-secondary mb-4">
                    <div class="card-header bg-secondary border-0">
                        <h5 class="font-weight-semi-bold m-0">Items Ordered</h5>
                    </div>
                    <div class="card-body p-0">
                        <table class="table table-bordered mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th>Product</th>
                                    <th class="text-center" style="width:80px;">Qty</th>
                                    <th class="text-right" style="width:120px;">Price</th>
                                    <th class="text-right" style="width:120px;">Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="align-middle">
                                        <div class="d-flex align-items-center">
                                            <?php if($product->images && $product->images->isNotEmpty()): ?>
                                                <img src="<?php echo e($product->images->first()->url); ?>"
                                                     alt="<?php echo e($product->name); ?>"
                                                     style="width:50px;height:50px;object-fit:cover;border-radius:4px;margin-right:12px;">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('eshopper/img/product-1.jpg')); ?>"
                                                     alt="<?php echo e($product->name); ?>"
                                                     style="width:50px;height:50px;object-fit:cover;border-radius:4px;margin-right:12px;">
                                            <?php endif; ?>
                                            <span><?php echo e($product->name); ?></span>
                                        </div>
                                    </td>
                                    <td class="text-center align-middle"><?php echo e($product->pivot->quantity); ?></td>
                                    <td class="text-right align-middle">₹<?php echo e(number_format($product->pivot->price, 2)); ?></td>
                                    <td class="text-right align-middle">₹<?php echo e(number_format($product->pivot->quantity * $product->pivot->price, 2)); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot class="bg-light">
                                <tr>
                                    <td colspan="3" class="text-right">Subtotal</td>
                                    <td class="text-right">₹<?php echo e(number_format($order->subtotal, 2)); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="3" class="text-right">Shipping</td>
                                    <td class="text-right">
                                        <?php if($order->shipping_cost == 0): ?>
                                            <span class="text-success">Free</span>
                                        <?php else: ?>
                                            ₹<?php echo e(number_format($order->shipping_cost, 2)); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php if($order->discount_amount > 0): ?>
                                <tr>
                                    <td colspan="3" class="text-right text-success">
                                        Discount
                                        <?php if($order->coupon_code): ?>
                                            <small>(<?php echo e($order->coupon_code); ?>)</small>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-right text-success">- ₹<?php echo e(number_format($order->discount_amount, 2)); ?></td>
                                </tr>
                                <?php endif; ?>
                                <tr>
                                    <td colspan="3" class="text-right font-weight-bold">Total</td>
                                    <td class="text-right font-weight-bold">₹<?php echo e(number_format($order->total_price, 2)); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>

                <!-- Shipping Address -->
                <div class="card border-secondary mb-4">
                    <div class="card-header bg-secondary border-0">
                        <h5 class="font-weight-semi-bold m-0">Shipping Address</h5>
                    </div>
                    <div class="card-body">
                        <p class="mb-1"><strong><?php echo e($order->shipping_full_name); ?></strong></p>
                        <p class="mb-1"><?php echo e($order->shipping_street); ?></p>
                        <p class="mb-1"><?php echo e($order->shipping_city); ?>, <?php echo e($order->shipping_state); ?> - <?php echo e($order->shipping_postal_code); ?></p>
                        <p class="mb-1"><?php echo e($order->shipping_country); ?></p>
                        <p class="mb-0"><i class="fa fa-phone mr-1 text-muted"></i><?php echo e($order->shipping_phone); ?></p>
                        <?php if($order->notes): ?>
                            <hr>
                            <p class="mb-0 text-muted"><i class="fa fa-sticky-note mr-1"></i><?php echo e($order->notes); ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Actions -->
                <div class="d-flex justify-content-between flex-wrap gap-2">
                    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-outline-dark px-4 py-3">
                        <i class="fa fa-shopping-bag mr-2"></i>Continue Shopping
                    </a>
                    <a href="<?php echo e(route('profile.order-details', $order->id)); ?>" class="btn btn-primary px-4 py-3">
                        <i class="fa fa-list mr-2"></i>View Order Details
                    </a>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.eshopper', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/prakash/urbandenim/resources/views/front/checkout-confirmation.blade.php ENDPATH**/ ?>